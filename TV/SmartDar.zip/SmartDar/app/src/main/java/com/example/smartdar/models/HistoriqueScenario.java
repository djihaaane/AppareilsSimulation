package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class HistoriqueScenario {


        @SerializedName("Historique_ID")
        @Expose
        private int historiqueID;
        @SerializedName("Historique_Date")
        @Expose
        private String historiqueDate;
        @SerializedName("Historique_Description")
        @Expose
        private int historiqueDescription;

    public HistoriqueScenario(int historique_id, int historique_description, String historique_date) {
    }

    public int getHistoriqueID() {
            return historiqueID;
        }

        public void setHistoriqueID(int historiqueID) {
            this.historiqueID = historiqueID;
        }

        public String getHistoriqueDate() {
            return historiqueDate;
        }

        public void setHistoriqueDate(String historiqueDate) {
            this.historiqueDate = historiqueDate;
        }

        public int getHistoriqueDescription() {
            return historiqueDescription;
        }

        public void setHistoriqueDescription(int historiqueDescription) {
            this.historiqueDescription = historiqueDescription;
        }

    }