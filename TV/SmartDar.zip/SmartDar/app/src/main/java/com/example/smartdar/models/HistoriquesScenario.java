package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class HistoriquesScenario {
     @SerializedName("historiqueScenario")
        @Expose
        private ArrayList<HistoriqueScenario> historiqueScenario;

    @SerializedName("lastScenario")
    @Expose
    private ArrayList<HistoriqueScenario> lastScenario;

        public ArrayList<HistoriqueScenario> getHistoriqueScenario() {
            return historiqueScenario;
        }

    public ArrayList<HistoriqueScenario> getLastScenario() {
        return lastScenario;
    }
}
