package com.example.smartdar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.Device;
import com.example.smartdar.models.Result;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

class DeviceAdapter extends RecyclerView.Adapter<DeviceAdapter.MyViewHolder> implements OnItemClickListener {
    private final String localhost="http://192.168.8.100/RetrofitSmartDar/Images/Appareil/";
    private ArrayList<Device> arraylist;

    private Context context;
    private List<Device> DeviceList;
    private Thread1 Thread1;
    int pos ;
    int type;
    String ip;

    public void filter(String text) {
        text = text.toLowerCase(Locale.getDefault());
        DeviceList.clear();
        if (text.length() == 0) {
            DeviceList.addAll(arraylist);
        } else {
            for (Device wp : arraylist) {
                if (wp.getAppareilName().toLowerCase(Locale.getDefault()).contains(text)) {
                    DeviceList.add(wp);
                }
            }
        }
        notifyDataSetChanged();
    }

    @Override
    public void onClick(View view, int position) {
        Bundle b = new Bundle();
        b.putInt("appareil_id",DeviceList.get(position).getAppareilID());
        b.putInt("pos",position);
        b.putInt("appareil_mode",DeviceList.get(position).getAppareilMode());
        b.putString("appareil_name",DeviceList.get(position).getAppareilName());
        b.putString("Appareil_Chambre",DeviceList.get(position).getAppareilChambre());
        b.putString("appareil_type",DeviceList.get(position).getAppareilTypeName());
        b.putString("appareil_info",DeviceList.get(position).getAppareil_Info());
        if (DeviceList.get(position).getAppareilTypeName().equals("Lampe") ||
                DeviceList.get(position).getAppareilTypeName().equals("Arroseur")||
                DeviceList.get(position).getAppareilTypeName().equals("Alarme")||
                DeviceList.get(position).getAppareilTypeName().equals("Serrure")||
                DeviceList.get(position).getAppareilTypeName().equals("Prise"))
        {

            Intent intent= new Intent(context.getApplicationContext(), DetailsDeviceSimple.class);
            intent.putExtras(b);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.getApplicationContext().startActivity(intent);
        }
        else
        {
            if (DeviceList.get(position).getAppareilTypeName().equals("Smart TV"))
            {
                Intent intent= new Intent(context.getApplicationContext(), TV_device_details.class);
                intent.putExtras(b);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.getApplicationContext().startActivity(intent);
            }
            else {
            Intent intent= new Intent(context.getApplicationContext(), DetailsDeviceAvec.class);
            intent.putExtras(b);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.getApplicationContext().startActivity(intent);}
        }
}


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView Device_title;
        public TextView Device_room;
        public ImageView Device_image;
        public com.kyleduo.switchbutton.SwitchButton Device_mode;
        public ImageButton btnDetails;

        public MyViewHolder(View view) {
            super(view);
            Device_title = view.findViewById(R.id.device_title);
            Device_image = view.findViewById(R.id.device_image);
            Device_room =view.findViewById(R.id.device_room);
            Device_mode = view.findViewById(R.id.device_mode);
            btnDetails=view.findViewById(R.id.detailAppareil);

        }
    }


    public DeviceAdapter(Context context, List<Device> DeviceList) {
        this.context = context;
        this.DeviceList = DeviceList;
        this.arraylist = new ArrayList<Device>();
        this.arraylist.addAll(DeviceList);

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.device_item_row, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(DeviceAdapter.MyViewHolder holder, final int position) {
        GlideApp.with(context)
                .load(localhost+DeviceList.get(position).getAppareilTypeImage()).into(holder.Device_image);
        holder.Device_room.setText(DeviceList.get(position).getAppareilChambre());
        holder.Device_title.setText(DeviceList.get(position).getAppareilName());
        if(DeviceList.get(position).getAppareilMode()==1)
            {
                holder.Device_mode.setChecked(true);
            }
        else
            {
                holder.Device_mode.setChecked(false);
            }

        holder.Device_mode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                    if (!DeviceList.get(position).getAppareilIP().equals("0"))
                    {
                        if(DeviceList.get(position).getAppareilTypeName().equals("Alarme"))
                        {
                            fetchData(DeviceList.get(position).getAppareilID(),1,DeviceList.get(position).getAppareil_Info());
                            // The toggle is enabled
                            System.out.println("on");
                        }
                        else {
                        pos=1;
                        type=DeviceList.get(position).getAppareilID();
                        ip=DeviceList.get(position).getAppareilIP();
                        Thread1 =new Thread1();
                        Thread1.start();
                        }
                    }
                    else
                    {
                        fetchData(DeviceList.get(position).getAppareilID(),1,DeviceList.get(position).getAppareil_Info());
                        // The toggle is enabled
                        System.out.println("on");
                    }

                } else {

                    if (!DeviceList.get(position).getAppareilIP().equals("0"))
                    {
                        if(DeviceList.get(position).getAppareilTypeName().equals("Alarme"))
                        {
                            fetchData(DeviceList.get(position).getAppareilID(),0,DeviceList.get(position).getAppareil_Info());
                            // The toggle is disabled

                            System.out.println("off");
                        }
                        else {

                        pos=0;
                        type=DeviceList.get(position).getAppareilID();
                        ip=DeviceList.get(position).getAppareilIP();
                        Thread1 =new Thread1();
                        Thread1.start(); }

                    }
                    else {
                        fetchData(DeviceList.get(position).getAppareilID(),0,DeviceList.get(position).getAppareil_Info());
                        // The toggle is disabled

                        System.out.println("off");
                    }
                }
            }
        });
        holder.btnDetails.setOnClickListener(new  View.OnClickListener(){@Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putInt("appareil_id",DeviceList.get(position).getAppareilID());
            b.putInt("pos",position);
            b.putInt("appareil_mode",DeviceList.get(position).getAppareilMode());
            b.putString("appareil_name",holder.Device_title.getText().toString());
            b.putString("Appareil_Chambre",DeviceList.get(position).getAppareilChambre());
            b.putString("appareil_type",DeviceList.get(position).getAppareilTypeName());
            b.putString("appareil_info",DeviceList.get(position).getAppareil_Info());
            b.putString("appareil_ip",DeviceList.get(position).getAppareilIP());
            if (DeviceList.get(position).getAppareilTypeName().equals("Lampe")||
                    DeviceList.get(position).getAppareilTypeName().equals("Arroseur"))
            {
                Intent intent= new Intent(context.getApplicationContext(), DetailsDeviceSimple.class);
                intent.putExtras(b);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.getApplicationContext().startActivity(intent);
            }
            else
            {  if (DeviceList.get(position).getAppareilTypeName().equals("Smart TV"))
            {
                Intent intent= new Intent(context.getApplicationContext(), TV_device_details.class);
                intent.putExtras(b);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.getApplicationContext().startActivity(intent);
            }else
            {
                Intent intent= new Intent(context.getApplicationContext(), DetailsDeviceAvec.class);
                intent.putExtras(b);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.getApplicationContext().startActivity(intent);
            }
            }
        }
        });
}
    private void fetchData(int Appareil_ID,int Appareil_Mode,String Appareil_Desc) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        String id=String.valueOf(Appareil_ID).trim();
        String mod=String.valueOf(Appareil_Mode).trim();
        Call<Result> call = api.sendAppareilMode(mod,id);
        Call<Result> call1 = api.sendHistoriqueAppareil(id,mod,Appareil_Desc.trim());

        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(context, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
        call1.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(context, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }

    @Override
    public int getItemCount() {
        return DeviceList.size();
    }

    private PrintWriter output;
    private BufferedReader input;

    public class Thread1 extends Thread implements Runnable {
        public void run() {
            Socket socket;
            try {
                System.out.println(ip);
                socket = new Socket(ip, 8080);
                output = new PrintWriter(socket.getOutputStream());

                PrintWriter writer = new PrintWriter(output, true);
                System.out.println(pos);
                writer.println(pos);
                writer.println(type);
                System.out.println(type);
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
