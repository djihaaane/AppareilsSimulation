package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class appareilsON {
    @SerializedName("appareilsON")
    @Expose
    private ArrayList<Device> appareilsON;

    public appareilsON() {
    }

    public ArrayList<Device> getAppList() {
        return appareilsON;
    }

    public void setAppList(ArrayList<Device> appList) {
        this.appareilsON = appList;
    }
}
