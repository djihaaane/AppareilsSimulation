package com.example.smartdar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.Device;
import com.example.smartdar.models.Result;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

class DeviceAdapterchambre extends RecyclerView.Adapter<DeviceAdapterchambre.MyViewHolder> {
    private final String localhost="http://192.168.8.100/RetrofitSmartDar/Images/Appareil/";

    private Context context;
    private List<Device> deviceList;
    private Thread1 Thread1;
    int pos ;
    int type;
    String ip;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView device_title;
        public TextView device_room;
        public ImageView device_image;
        public com.kyleduo.switchbutton.SwitchButton device_mode;
        public ImageButton btnDetails;


        public MyViewHolder(View view) {
            super(view);
            device_title = view.findViewById(R.id.device_title);
            device_image = view.findViewById(R.id.device_image);
            device_room = view.findViewById(R.id.device_room);
            device_mode = view.findViewById(R.id.device_mode);
            btnDetails =view.findViewById(R.id.detailAppareil);


        }
    }


    public DeviceAdapterchambre(Context context, List<Device> deviceList) {
        this.context = context;
        this.deviceList = deviceList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.device_chambre_card, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(DeviceAdapterchambre.MyViewHolder holder, final int position) {
        GlideApp.with(context)
                .load(localhost+deviceList.get(position).getAppareilTypeImage()).into(holder.device_image);
        holder.device_title.setText(deviceList.get(position).getAppareilName());
        if(deviceList.get(position).getAppareilMode()==1)
        {
            holder.device_mode.setChecked(true);}
        else
        {   holder.device_mode.setChecked(false);}

        holder.device_mode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {

                    if (!deviceList.get(position).getAppareilIP().equals("0"))
                    {

                        if(deviceList.get(position).getAppareilTypeName().equals("Alarme"))
                        {
                            fetchData(deviceList.get(position).getAppareilID(),1,deviceList.get(position).getAppareil_Info());
                            // The toggle is enabled
                            System.out.println("on");
                        }
                        else {



                            pos=1;
                        type=deviceList.get(position).getAppareilID();
                        ip=deviceList.get(position).getAppareilIP();
                        Thread1 =new Thread1();
                        Thread1.start();
                        }
                    }
                    else
                    {
                        fetchData(deviceList.get(position).getAppareilID(),1,deviceList.get(position).getAppareil_Info());
                        // The toggle is enabled
                        System.out.println("on");
                    }

                } else {

                    if (!deviceList.get(position).getAppareilIP().equals("0"))
                    {
                        if(deviceList.get(position).getAppareilTypeName().equals("Alarme"))
                        {
                            fetchData(deviceList.get(position).getAppareilID(),0,deviceList.get(position).getAppareil_Info());
                            // The toggle is disabled

                            System.out.println("off");
                        }
                        else {


                            pos=0;
                        type=deviceList.get(position).getAppareilID();
                        ip=deviceList.get(position).getAppareilIP();
                        Thread1 =new Thread1();
                        Thread1.start();
                        }
                    }
                    else {
                        fetchData(deviceList.get(position).getAppareilID(),0,deviceList.get(position).getAppareil_Info());
                        // The toggle is disabled

                        System.out.println("off");
                    }
                }
            }
        });
            holder.btnDetails.setOnClickListener(new  View.OnClickListener(){@Override
        public void onClick(View v) {
            Bundle b = new Bundle();
            b.putInt("appareil_id",deviceList.get(position).getAppareilID());
            b.putInt("pos",position);
            b.putInt("appareil_mode",deviceList.get(position).getAppareilMode());
            b.putString("appareil_name",holder.device_title.getText().toString());
            b.putString("Appareil_Chambre",deviceList.get(position).getAppareilChambre());
            b.putString("appareil_type",deviceList.get(position).getAppareilTypeName());
            b.putString("appareil_info",deviceList.get(position).getAppareil_Info());
            b.putString("appareil_ip",deviceList.get(position).getAppareilIP());
                if (deviceList.get(position).getAppareilTypeName().equals("Lampe") ||
                    deviceList.get(position).getAppareilTypeName().equals("Arroseur")||
                deviceList.get(position).getAppareilTypeName().equals("Alarme")||
                    deviceList.get(position).getAppareilTypeName().equals("Serrure")||
                    deviceList.get(position).getAppareilTypeName().equals("Prise"))
            {

            Intent intent= new Intent(context.getApplicationContext(), DetailsDeviceSimple.class);
            intent.putExtras(b);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.getApplicationContext().startActivity(intent);
            }
            else
                {
                    if (deviceList.get(position).getAppareilTypeName().equals("Smart TV"))
                    {
                        Intent intent= new Intent(context.getApplicationContext(), TV_device_details.class);
                        intent.putExtras(b);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.getApplicationContext().startActivity(intent);
                    }else
                    {
                    Intent intent= new Intent(context.getApplicationContext(), DetailsDeviceAvec.class);
                    intent.putExtras(b);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.getApplicationContext().startActivity(intent);
                    }
                 }

        }

        });
    }

    @Override
    public int getItemCount() {
        return deviceList.size();
    }

    private void fetchData(int Appareil_ID,int Appareil_Mode,String Appareil_Desc) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        String id=String.valueOf(Appareil_ID).trim();
        String mod=String.valueOf(Appareil_Mode).trim();
        Call<Result> call = api.sendAppareilMode(mod,id);
        Call<Result> call1=api.sendHistoriqueAppareil(id,mod,Appareil_Desc.trim());
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(context, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
        call1.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage()+"       historiqueApppareil");

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(context, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
}

    private PrintWriter output;
    private BufferedReader input;

    public class Thread1 extends Thread implements Runnable {
        public void run() {
            Socket socket;
            try {
                System.out.println(ip);
                socket = new Socket(ip, 8080);
                output = new PrintWriter(socket.getOutputStream());

                PrintWriter writer = new PrintWriter(output, true);
                System.out.println(pos);
                writer.println(pos);
                writer.println(type);
                System.out.println(type);
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
