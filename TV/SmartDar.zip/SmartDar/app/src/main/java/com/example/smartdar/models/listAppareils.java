package com.example.smartdar.models;

public class listAppareils {
}
