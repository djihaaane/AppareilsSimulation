package com.example.smartdar.models;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Chambre {

    @SerializedName("Chambre_ID")
    @Expose
    private int chambreID;
    @SerializedName("Chambre_Name")
    @Expose
    private String chambreName;
    @SerializedName("Chambre_Image")
    @Expose
    private String chambreImage;
    @SerializedName("nbr_App")
    @Expose
    private String nbrApp;

    public int getChambreID() {
        return chambreID;
    }

    public Chambre(int chambreID, String chambreName, String chambreImage) {
        this.chambreID = chambreID;
        this.chambreName = chambreName;
        this.chambreImage = chambreImage;
    }

    public void setChambreID(int chambreID) {
        this.chambreID = chambreID;
    }

    public String getChambreName() {
        return chambreName;
    }

    public void setChambreName(String chambreName) {
        this.chambreName = chambreName;
    }

    public String getChambreImage() {
        return chambreImage;
    }

    public void setChambreImage(String chambreImage) {
        this.chambreImage = chambreImage;
    }

    public String  getNbrApp() {
        return nbrApp;
    }

    public void setNbrApp(String nbrApp) {
        this.nbrApp = nbrApp;
    }

}