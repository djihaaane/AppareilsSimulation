package com.example.smartdar;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.api.WeatherService;
import com.example.smartdar.models.appareilsON;
import com.example.smartdar.models.listScenario;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link maisonFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class maisonFragment extends Fragment implements LocationListener {
    private SharedPreferences sharedpreference;

    private static final int REQUEST_LOCATION = 1;
    Geocoder geocoder;
    String bestProvider;
    List<Address> user = null;
    double lat;
    double lng;

    private static final String OPEN_WEATHER_MAP_API =
            "https://api.openweathermap.org/";
    Typeface weatherFont;
    FloatingActionButton fab;
    MaterialButton exit;
    TextView cityField;
    TextView updatedField;
    private SharedPreferences sharedpreferences;
    TextView detailsField;
    TextView currentTemperatureField;
    TextView weatherIcon;
    Handler handler;
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private DeviceAdapter adapter;
    private ScenarioMaisonAdapter adapter1;

    private RecyclerView recyclerViewsm;

    private RecyclerView recyclerViewam;
    private String AppId= "d3f78ea17d39fdf8f471982c105e455c";

    public maisonFragment() {
        // Required empty public constructor

        handler = new Handler();
    }

    public static maisonFragment newInstance(String param1, String param2) {
        maisonFragment fragment = new maisonFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        sharedpreference = getContext().getSharedPreferences("weather", 0); // 0 - for private mode

        weatherFont = Typeface.createFromAsset(Objects.requireNonNull(getActivity()).getAssets(), "weather.ttf");

        fetchData();

    }


    public void onLocationChanged(Location location) {
        lat=location.getLatitude();
        lng=location.getLongitude();

        SharedPreferences.Editor editor = sharedpreference.edit();
        editor.putFloat("lat", (float) lat);
        editor.putFloat("lng", (float) lng);
        editor.apply();
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {


    }

    @Override
    public void onProviderEnabled(String s) {


    }

    @Override
    public void onProviderDisabled(String s) {
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_maison, container, false);
        weatherFont = Typeface.createFromAsset(Objects.requireNonNull(getActivity()).getAssets(), "weather.ttf");
        cityField = (TextView) view.findViewById(R.id.city_field);
        updatedField = (TextView) view.findViewById(R.id.updated_field);
        detailsField = (TextView) view.findViewById(R.id.details_field);
        currentTemperatureField = (TextView) view.findViewById(R.id.current_temperature_field);
        weatherIcon = (TextView) view.findViewById(R.id.weather_icon);
        recyclerViewsm = view.findViewById(R.id.recycler_viewsm);
        exit = view.findViewById(R.id.exit);
        fab = view.findViewById(R.id.fab);
        recyclerViewam = view.findViewById(R.id.recycler_viewam);
        weatherIcon.setTypeface(weatherFont);

        ActivityCompat.requestPermissions( getActivity(),
                new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        String c=sharedpreference.getString("city","");
              getLocation();
              getCurrentData();
        cityField.setText(c);

        detailsField.setText("Humidite: "+sharedpreference.getInt("Humidite", 0)+"%");
        currentTemperatureField.setText(
                String.format("%.0f",sharedpreference.getFloat("temp", 0)));

        updatedField.setText("MAJ: " +sharedpreference.getString("MAJ", ""));

        setWeatherIcon(sharedpreference.getInt("id", 0),
                sharedpreference.getLong("rise", 0),
                sharedpreference.getLong("set", 0));
        weatherIcon.setTypeface(weatherFont);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), SosActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sharedpreferences = getContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putBoolean("error", true);
                editor.apply();
                Intent intent = new Intent(getContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });
     return view;

}

 private void setWeatherIcon(int actualId, long sunrise, long sunset){
        int id = actualId / 100;
        String icon=getString(R.string.def) ;
        if(actualId == 800){
            long currentTime = new Date().getTime();
            if(currentTime>=sunrise && currentTime<sunset) {
                icon = getActivity().getString(R.string.weather_sunny);
            } else {
                icon = getActivity().getString(R.string.weather_clear_night);
            }
        } else {
            switch(id) {
                case 2 : icon = getActivity().getString(R.string.weather_thunder);
                    break;
                case 3 : icon = getActivity().getString(R.string.weather_drizzle);
                    break;
                case 7 : icon = getActivity().getString(R.string.weather_foggy);
                    break;
                case 8 : icon = getActivity().getString(R.string.weather_cloudy);
                    break;
                case 6 : icon = getActivity().getString(R.string.weather_snowy);
                    break;
                case 5 : icon = getActivity().getString(R.string.weather_rainy);
                    break;
                case 4 : icon = getActivity().getString(R.string.weather_clear_night);
                    break;
            }
        }
     weatherIcon.setTypeface(weatherFont);
     weatherIcon.setText(icon);

 }

    private void fetchData() {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);


        Call<appareilsON> call = api.get_all_appareilsON();
        Call<listScenario> call1 = api.scenariosFav();
        call.enqueue(new Callback<appareilsON>() {
            @Override
            public void onResponse(Call<appareilsON> call, Response<appareilsON> response) {
                adapter = new DeviceAdapter(getContext(),response.body().getAppList());
                recyclerViewam.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
                recyclerViewam.setAdapter(adapter);


            }

            @Override
            public void onFailure(Call<appareilsON> call, Throwable t) {

                Toast.makeText(getContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
        call1.enqueue(new Callback<listScenario>() {
            @Override
            public void onResponse(Call<listScenario> call, Response<listScenario> response) {
                adapter1 = new ScenarioMaisonAdapter(getContext(),response.body().getScenariosFav());
                recyclerViewsm.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
                recyclerViewsm.setAdapter(adapter1);


            }

            @Override
            public void onFailure(Call<listScenario> call, Throwable t) {

                Toast.makeText(getContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }
    void getCurrentData() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(OPEN_WEATHER_MAP_API)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        WeatherService service = retrofit.create(WeatherService.class);
        Call<WeatherResponse> call = service.getCurrentWeatherData(String.valueOf(sharedpreference.getFloat("lat",0))
                ,String.valueOf( sharedpreference.getFloat("lng",0)), AppId);
        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(@NonNull Call<WeatherResponse> call, @NonNull Response<WeatherResponse> response) {
                if (response.code() == 200) {
                    WeatherResponse weatherResponse = response.body();

                    DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
                    String updatedOn = df.format(new Date(weatherResponse.dt*1000));

                    SharedPreferences.Editor editor = sharedpreference.edit();
                    editor.putString("city", weatherResponse.name.toUpperCase(Locale.US) +
                            ", " +
                            weatherResponse.sys.country);
                    editor.putFloat("lat", (float) lat);
                    editor.putFloat("lng", (float) lng);
                    editor.putInt("Humidite",weatherResponse.main.humidity);
                    editor.putString("MAJ",updatedOn);
                    editor.putInt("id",weatherResponse.sys.id);
                    editor.putFloat("temp", (float) (weatherResponse.main.temp-273.15));
                    editor.putLong("rise",weatherResponse.sys.sunrise * 1000);
                    editor.putLong("set",weatherResponse.sys.sunset * 1000);
                    System.out.println(sharedpreference.getFloat("lat",0));
                    System.out.println("rgreohjmerohamjreaom");
                    System.out.println(sharedpreference.getString("city",""));

                    editor.apply();
            }

                }
      void onResume()
      { weatherFont = Typeface.createFromAsset(Objects.requireNonNull(getActivity()).getAssets(), "weather.ttf");
          fetchData();
          maisonFragment.super.onResume();

      }
            @Override
            public void onFailure(@NonNull Call<WeatherResponse> call, @NonNull Throwable t) {
                System.out.println(t.getMessage());
            }
        });
    }

public void getLocation(){
            LocationManager nManager = (LocationManager) Objects.requireNonNull(getActivity()).
                    getSystemService(Context.LOCATION_SERVICE);
            if (!nManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {

            } else {
                if (ActivityCompat.checkSelfPermission(
                        getContext(), Manifest.permission.ACCESS_FINE_LOCATION) !=
                        PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(
                        getContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(getActivity(),
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            REQUEST_LOCATION);
                } else {


                    LocationManager lm = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);

                    Criteria criteria = new Criteria();
                    bestProvider = lm.getBestProvider(criteria, false);
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 10,this);
                    Location location = lm.getLastKnownLocation(bestProvider);

                    if (location == null){
                        Toast.makeText(getActivity(),"Location Not found",Toast.LENGTH_LONG).show();
                    }else{
                        geocoder = new Geocoder(getActivity());
                        try {
                            user = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                            lat=(double)user.get(0).getLatitude();
                            lng=(double)user.get(0).getLongitude();
                            System.out.println("lat  lng"+lat+"     "+lng);

                            getCurrentData();

                        }catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    getCurrentData();

                }
            }


        }
    }
