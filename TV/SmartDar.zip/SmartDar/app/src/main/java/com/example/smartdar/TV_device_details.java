package com.example.smartdar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.HistoriquesDevice;
import com.example.smartdar.models.Result;
import com.google.android.material.button.MaterialButton;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TV_device_details extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private final Handler handler;
    RecyclerView recyclerView;
    HistoriqueDeviceAdapter adapter;

    String item;
    private TextView appareil_name;
    private TextView appareil_chambre;
    private TextView appareil_type;
    private TextView duree;
    private Toolbar toolbar;
    private MaterialButton btninc;
    private MaterialButton btndecr;
    private MaterialButton changerTemp;
    private TextView active;
    private TextView desactive;
    static Timestamp timestamp,timestamp1,ts;
    int mod;
    String info;
    String action;
    String ip;
    int pos;
    Spinner spinner;
    private MaterialButton afficher;
    LinearLayout layout;
    private boolean i=false;

    public TV_device_details() {
        handler = new Handler();

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tv_device_details);
        // Spinner element
        recyclerView =(RecyclerView) findViewById(R.id.recycler_view1);
        MaterialButton ok = (MaterialButton) findViewById(R.id.ok);
        MaterialButton volup = (MaterialButton) findViewById(R.id.volup);
        MaterialButton voldown = (MaterialButton) findViewById(R.id.voldown);
        MaterialButton mute = (MaterialButton) findViewById(R.id.mute);
        MaterialButton prev = (MaterialButton) findViewById(R.id.prev);
        MaterialButton next = (MaterialButton) findViewById(R.id.next);
        afficher=findViewById(R.id.afficherHist);
        layout=findViewById(R.id.layout_his);
        duree =(TextView) findViewById(R.id.duree);
        com.kyleduo.switchbutton.SwitchButton  appareil_mode=(com.kyleduo.switchbutton.SwitchButton)findViewById(R.id.device_mode_details);
        appareil_chambre =(TextView) findViewById(R.id.chambre_name_app_details);
        appareil_type =(TextView) findViewById(R.id.type_app_details);
        appareil_name =(TextView) findViewById(R.id.appareil_name_details);


        active =(TextView) findViewById(R.id.textView5);
        desactive =(TextView) findViewById(R.id.textView4);
        toolbar= (Toolbar)findViewById(R.id.toolbardetail);
        toolbar.setOnMenuItemClickListener(tbMenuLisner);


        Bundle bundle = getIntent().getExtras();
        String result =String.valueOf(bundle.getInt("appareil_id"));
        mod=bundle.getInt("appareil_mode");
        int pos=bundle.getInt("pos");
        if(mod==1)
        {
            appareil_mode.setChecked(true);
            System.out.println(mod);}
        else
        {   appareil_mode.setChecked(false);
            System.out.println(mod);
        }
        String name=bundle.getString("appareil_name");
        String desc=bundle.getString("appareil_info");
        String Appareil_Chambre=bundle.getString("Appareil_Chambre");
        String type=bundle.getString("appareil_type");
        ip=bundle.getString("appareil_ip");
        int id=bundle.getInt("appareil_id");
        appareil_name.setText(name);
        appareil_chambre.setText(Appareil_Chambre);
        appareil_type.setText(type);
        fetchData(result);
        ok.setOnClickListener(new View.OnClickListener() {
            private Thread1 Thread1;

            @Override
            public void onClick(View view) {
                action="ok";
                info= String.valueOf(spinner.getSelectedItemPosition());
                Thread1 =new Thread1();
                Thread1.start();

            }
        });

        voldown.setOnClickListener(new View.OnClickListener() {
            private Thread1 Thread1;

            @Override
            public void onClick(View view) {

                action="voldown";
                info="1";
                Thread1 =new Thread1();
                Thread1.start();
            }
        });
        volup.setOnClickListener(new View.OnClickListener() {
            private Thread1 Thread1;
            @Override
            public void onClick(View view) {
                action="volup";
                info="1";
                Thread1 =new Thread1();
                Thread1.start();

            }
        });
        prev.setOnClickListener(new View.OnClickListener() {
            private Thread1 Thread1;
            @Override
            public void onClick(View view) {
                action="prev";
                if ((spinner.getSelectedItemPosition()-1)==-1)
                {
                    info= String.valueOf(3);
                }
                else {
                    spinner.setSelection(spinner.getSelectedItemPosition()-1);
                info=String.valueOf(spinner.getSelectedItemPosition()-1);
                }
                Thread1 =new Thread1();
                Thread1.start();

            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            private Thread1 Thread1;

            @Override
            public void onClick(View view) {
                action="next";
                if ((spinner.getSelectedItemPosition()-1)==4)
                {
                    info= String.valueOf(0);
                }
                else {
                    spinner.setSelection(spinner.getSelectedItemPosition()+1);
                    System.out.println(spinner.getSelectedItemPosition());
                    info=String.valueOf(spinner.getSelectedItemPosition()+1);}
                Thread1 =new Thread1();
                Thread1.start();

            }
        });

        mute.setOnClickListener(new View.OnClickListener() {
            private Thread1 Thread1;

            @Override
            public void onClick(View view) {
                action="mute";
                info="0";
                Thread1 =new Thread1();
                Thread1.start();

            }
        });

        afficher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!i)
                {
                    layout.setVisibility(View.VISIBLE);
                    afficher.setText("Cacher historique");
                    i=true;
                }else
                {
                    layout.setVisibility(View.GONE);
                    i=false;
                }
            }
        });


        appareil_mode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            private Thread1 Thread1;

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    action="1";
                    info= String.valueOf(id);
                    Thread1 =new Thread1();
                    Thread1.start();
                } else {
                    action="0";
                    info=String.valueOf(id);
                    Thread1 =new Thread1();
                    Thread1.start();

                }
            }
        });


       spinner = (Spinner) findViewById(R.id.spinner);

        // Spinner click listener
        spinner.setOnItemSelectedListener(this);

        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("NBC");
        categories.add("Arte");
        categories.add("Bein Sports");
        categories.add("TF1");

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
       item = parent.getItemAtPosition(position).toString();
       pos=position;

    }
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }





    @SuppressLint("NewApi")
    private void fetchData(String appareil_id) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);


        Call<HistoriquesDevice> call = api.get_all_historiques_Appareil(appareil_id);
        Call<HistoriquesDevice> call1 = api.get_lastOffOn(appareil_id);



        call.enqueue(new Callback<HistoriquesDevice>() {
            @Override
            public void onResponse(Call<HistoriquesDevice> call, Response<HistoriquesDevice> response) {
                adapter = new HistoriqueDeviceAdapter(getApplicationContext(),response.body().getHistoriquesDevices());
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                recyclerView.setAdapter(adapter);


            }

            @Override
            public void onFailure(Call<HistoriquesDevice> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage()+"2");

            }
        });

        call1.enqueue(new Callback<HistoriquesDevice>() {
            @Override
            public void onResponse(Call<HistoriquesDevice> call, Response<HistoriquesDevice> response1) {
                if (response1.body().getLastOffOn().isEmpty())
                {
                    desactive.setText("-");
                    active.setText("-");

                }
                else {

                    desactive.setText(response1.body().getLastOffOn().get(0).getHistorique_Date_Off());

                    active.setText(response1.body().getLastOffOn().get(0).getHistorique_Date_On());

                    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date d = null;
                    Date d1 = null;

                    try {
                        //convert string to date
                        d = inputFormat.parse(response1.body()
                                .getLastOffOn().get(0).getHistorique_Date_On());
                    } catch (ParseException e) {
                        System.out.println("Date Format Not Supported");
                        e.printStackTrace();
                    }
                    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    timestamp1 = Timestamp.valueOf(outputFormat.format(d));
                    Date date = new Date();
                    //getTime() returns current time in milliseconds
                    long time = date.getTime();
                    //Passed the milliseconds to constructor of Timestamp class
                    Timestamp ts = new Timestamp(time);
                    if (mod==1)
                    {
                        Duration duration= Duration.between(ts.toInstant(),timestamp1.toInstant());
                        System.out.println(duration.toMinutes());
                        System.out.println(( Math.floorMod(-duration.toMinutes(),60))+"" +
                                "          "+Math.floorDiv(-duration.toMinutes(),60));
                        duree.setText(Math.floorDiv(-duration.toMinutes(),60)+"h et "+Math.floorMod(-duration.toMinutes(),60)+"min");
                    }
                    else
                    {
                        duree.setText(response1.body().getLastOffOn().get(0).getHeures()+"h et "+
                                response1.body().getLastOffOn().get(0).getMinutes()+"min");

                    }
                }}

            @Override
            public void onFailure(Call<HistoriquesDevice> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage()+"4");

            }
        });

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_app_bar_details, menu);
        System.out.println("darr menu");
        return true;
    }
    private void fetchData2(int Appareil_ID,String Appareil_Info) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        String id=String.valueOf(Appareil_ID).trim();
        String mod=String.valueOf(Appareil_Info).trim();
        Call<Result> call = api.sendAppareilDesc(mod,id);

        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(getApplication(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage()+"1");

            }
        });
    }
    private Toolbar.OnMenuItemClickListener  tbMenuLisner= new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();
            //noinspection SimplifiableIfStatement
            if (id == R.id.retour) {
                System.out.println("dkheel bch pressed");
                supportFinishAfterTransition();
                System.out.println(" pressed");
                return true;
            }
            return false;
        }
    };


    private PrintWriter output;
    private BufferedReader input;

    public class Thread1 extends Thread implements Runnable {
        public void run() {
            Socket socket;
            try {
                System.out.println(ip);
                socket = new Socket(ip, 8080);
                output = new PrintWriter(socket.getOutputStream());

                PrintWriter writer = new PrintWriter(output, true);
                writer.println(action);
                writer.println(info);
                System.out.println(info);
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}