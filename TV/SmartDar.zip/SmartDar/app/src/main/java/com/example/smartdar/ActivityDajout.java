package com.example.smartdar;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.Result;
import com.example.smartdar.models.appareilsChambre;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivityDajout extends AppCompatActivity implements SearchView.OnQueryTextListener,OnItemClickListener {
    SearchView searchView ;
    private RecyclerView recyclerView1;
    DeviceAddAdapter adapter;
    String result;
       int nbr=0;
    private Toolbar toolbar;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dajout);
        toolbar= (Toolbar)findViewById(R.id.toolbar);
        toolbar.setOnMenuItemClickListener(tbMenuLisner);
        recyclerView1 =(RecyclerView) findViewById(R.id.recycler_view1);
        searchView =(SearchView) findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(this);
         bundle = getIntent().getExtras();
        result =String.valueOf(bundle.getString("scenario_id"));
        fetchData(result);
        recyclerView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_app_bar_details, menu);
        return true;
    }
    private Toolbar.OnMenuItemClickListener  tbMenuLisner= new Toolbar.OnMenuItemClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();
            //noinspection SimplifiableIfStatement
            if (id == R.id.retour) {

                getIntent().putExtra("class","Ajout");

                Intent intent=getIntent();
                intent.putExtra("nbr",nbr);
                System.out.println(intent.getIntExtra("nbr",0));
                setResult(2,intent);
                finishAfterTransition();
                return true;
            }
            return false;
        }
    };

    private void fetchData(String id) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);


        Call<appareilsChambre> call = api.get_all_appareilsNotScenario(id);

        call.enqueue(new Callback<appareilsChambre>() {
            @Override
            public void onResponse(Call<appareilsChambre> call, Response<appareilsChambre> response) {
                System.out.println(response.body().getAppareilNotsScenario());
                adapter = new DeviceAddAdapter(getApplicationContext(),response.body().getAppareilNotsScenario());
                GridLayoutManager mGridLayoutManager = new GridLayoutManager(ActivityDajout.this, 3);
                recyclerView1.setLayoutManager(mGridLayoutManager);
                recyclerView1.setAdapter(adapter);
                adapter.setClickListener(ActivityDajout.this);


            }

            @Override
            public void onFailure(Call<appareilsChambre> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        String text = newText;
        adapter.filter(text);
        return false;
    }

    @Override
    public void onClick(View view, int position) {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.add_dialog);
        EditText desc=(EditText)dialog.findViewById(R.id.desc_edit);
        com.kyleduo.switchbutton.SwitchButton etat =(com.kyleduo.switchbutton.SwitchButton) dialog.findViewById(R.id.etat_edit);
        MaterialButton add_button=(MaterialButton)dialog.findViewById(R.id.add_button);
        MaterialButton cancel_button=(MaterialButton)dialog.findViewById(R.id.cancel_button);

        LinearLayout info=dialog.findViewById(R.id.info);
        TextView infoText=dialog.findViewById(R.id.infoText);
        if (adapter.DeviceList.get(adapter.pos).getAppareilTypeName().equals("Smart TV") )
        {    info.setVisibility(View.VISIBLE);
            infoText.setText("Chaine :");
        }
        if (adapter.DeviceList.get(adapter.pos).getAppareilTypeName().equals("Climatiseur")||adapter.DeviceList.get(adapter.pos).getAppareilTypeName().equals("Radiateur"))
        {
            info.setVisibility(View.VISIBLE);
        }
        dialog.setCancelable(true);
        final int[] etatt = new int[1];
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nbr++;
               if(etat.isChecked())
                   etatt[0] =1;
               else
                   etatt[0] =0;

                ajouterAppareilScenario(adapter.DeviceList.get(adapter.pos).getAppareilID(),
                        Integer.valueOf(result), String.valueOf(etatt[0]),desc.getText().toString());
                adapter.DeviceList.remove(position);
                adapter.notifyItemRemoved(position);
                dialog.dismiss();
            }
        });

        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }
    private void ajouterAppareilScenario(int Appareil_ID, int Scenario_ID, String Appareil_Scenario_Mode, String Appareil_Scenario_Desc) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        String id = String.valueOf(Appareil_ID).trim();
        String mod = String.valueOf(Scenario_ID).trim();
        Call<Result> call = api.ajouterAppareilsScenario(mod, id, Appareil_Scenario_Mode, Appareil_Scenario_Desc);
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(ActivityDajout.this, "" + t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }

}
