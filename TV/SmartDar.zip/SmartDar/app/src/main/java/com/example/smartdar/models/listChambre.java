package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class listChambre {
    @SerializedName("chambres")
    @Expose
    private ArrayList<Chambre> chambres;

    public listChambre() {
    }

    public ArrayList<Chambre> getChambres() {
        return chambres;
    }

    public void setChambres(ArrayList<Chambre> chambres) {
        this.chambres = chambres;
    }

}
