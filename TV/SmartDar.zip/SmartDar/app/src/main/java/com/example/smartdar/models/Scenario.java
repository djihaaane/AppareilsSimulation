package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Scenario {

    @SerializedName("Scenario_ID")
    @Expose
    private int scenarioID;
    @SerializedName("Scenario_Name")
    @Expose
    private String scenarioName;
    @SerializedName("Scenario_Mode")
    @Expose
    private int scenarioMode;
    @SerializedName("Scenario_Image")
    @Expose
    private String scenarioImage;
    @SerializedName("nbr_App")
    @Expose
    private String nbrApp;
    
    @SerializedName("favoris")
    @Expose
    private int favoris;

    public int getScenarioID() {
        return scenarioID;
    }

    public void setScenarioID(int scenarioID) {
        this.scenarioID = scenarioID;
    }

    public String getScenarioName() {
        return scenarioName;
    }

    public void setScenarioName(String scenarioName) {
        this.scenarioName = scenarioName;
    }

    public int getScenarioMode() {
        return scenarioMode;
    }

    public void setScenarioMode(int scenarioMode) {
        this.scenarioMode = scenarioMode;
    }

    public String getScenarioImage() {
        return scenarioImage;
    }

    public void setScenarioImage(String scenarioImage) {
        this.scenarioImage = scenarioImage;
    }

    public String getNbrApp() {
        return nbrApp;
    }

    public void setNbrApp(String nbrApp) {
        this.nbrApp = nbrApp;
    }

    public int isfavoris() {
        return favoris;
    }

    public void setfavoris(int  favoris) {
        this.favoris = favoris;
    }
}
