package com.example.smartdar.models;

import android.graphics.drawable.Drawable;

public class AU {
    Drawable image;
    String name;
    String num;

    public AU(Drawable image, String name, String num) {
        this.image = image;
        this.name = name;
        this.num = num;
    }

    public Drawable getImage() {
        return image;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

}
