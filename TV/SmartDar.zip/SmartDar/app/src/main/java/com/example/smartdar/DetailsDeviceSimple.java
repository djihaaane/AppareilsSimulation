package com.example.smartdar;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.HistoriquesDevice;
import com.google.android.material.button.MaterialButton;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailsDeviceSimple extends AppCompatActivity {
    private final Handler handler;
    RecyclerView recyclerView1;
    HistoriqueDeviceSimpleAdapter adapter;
    private TextView appareil_name;
    private com.kyleduo.switchbutton.SwitchButton appareil_mode;
    private TextView appareil_chambre;
    private TextView appareil_type;
    private Toolbar toolbar;
    private TextView active;
    private TextView desactive;
    private TextView duree;
    int mod;
    static Timestamp timestamp,timestamp1,ts;
    private MaterialButton afficher;
    private boolean i=false;


    public DetailsDeviceSimple() {
        handler = new Handler();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_device_simple);
        recyclerView1 =(RecyclerView) findViewById(R.id.recycler_view);
       appareil_name =(TextView) findViewById(R.id.appareil_name_details);
        appareil_chambre =(TextView) findViewById(R.id.chambre_name_app_details);
        appareil_type =(TextView) findViewById(R.id.type_app_details);
        active =(TextView) findViewById(R.id.textView5);
        afficher=findViewById(R.id.afficherHist);
        LinearLayout layout=findViewById(R.id.layout_his);
        desactive =(TextView) findViewById(R.id.textView4);
        duree =(TextView) findViewById(R.id.duree);
        appareil_mode=findViewById(R.id.device_mode_details);
        toolbar= (Toolbar)findViewById(R.id.toolbardetail);
        toolbar.setOnMenuItemClickListener(tbMenuLisner);
        Bundle bundle = getIntent().getExtras();
        String result =String.valueOf(bundle.getInt("appareil_id"));
         mod=bundle.getInt("appareil_mode");
        if(mod==1)
        {
            appareil_mode.setChecked(true);}
        else
        {   appareil_mode.setChecked(false);}

        String name=bundle.getString("appareil_name");
        String Appareil_Chambre=bundle.getString("Appareil_Chambre");
        String type=bundle.getString("appareil_type");
        appareil_name.setText(name);
        appareil_chambre.setText(Appareil_Chambre);
        appareil_type.setText(type);



        afficher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!i)
                {
                    layout.setVisibility(View.VISIBLE);
                    afficher.setText("Cacher historique");
                    i=true;
                }else
                {
                    layout.setVisibility(View.GONE);
                    i=false;
                }
            }
        });

        fetchData(result);

        appareil_mode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    fetchData(result);
                } else {
                    fetchData(result);

                }
            }
        });

    }


    @SuppressLint("NewApi")
    private void fetchData(String appareil_id) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);


        Call<HistoriquesDevice> call = api.get_all_historiques_Appareil(appareil_id);
        Call<HistoriquesDevice> call1 = api.get_lastOffOn(appareil_id);



        call.enqueue(new Callback<HistoriquesDevice>() {
            @Override
            public void onResponse(Call<HistoriquesDevice> call, Response<HistoriquesDevice> response) {
                adapter = new HistoriqueDeviceSimpleAdapter(getApplicationContext(),response.body().getHistoriquesDevices());
                recyclerView1.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                recyclerView1.setAdapter(adapter);


            }

            @Override
            public void onFailure(Call<HistoriquesDevice> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage()+"2");

            }
        });

        call1.enqueue(new Callback<HistoriquesDevice>() {
            @Override
            public void onResponse(Call<HistoriquesDevice> call, Response<HistoriquesDevice> response1) {
                if (response1.body().getLastOffOn().isEmpty())
                {
                    desactive.setText("-");
                    active.setText("-");

                }
                else {

                    desactive.setText(response1.body().getLastOffOn().get(0).getHistorique_Date_Off());

                    active.setText(response1.body().getLastOffOn().get(0).getHistorique_Date_On());

                    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date d = null;
                    Date d1 = null;

                    try {
                        //convert string to date
                        d = inputFormat.parse(response1.body()
                                .getLastOffOn().get(0).getHistorique_Date_On());
                    } catch (ParseException e) {
                        System.out.println("Date Format Not Supported");
                        e.printStackTrace();
                    }
                    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    timestamp1 = Timestamp.valueOf(outputFormat.format(d));
                    Date date = new Date();
                    //getTime() returns current time in milliseconds
                    long time = date.getTime();
                    //Passed the milliseconds to constructor of Timestamp class
                    Timestamp ts = new Timestamp(time);
                    if (mod==1)
                    {
                        Duration duration= Duration.between(ts.toInstant(),timestamp1.toInstant());
                        System.out.println(duration.toMinutes());
                        System.out.println(( Math.floorMod(-duration.toMinutes(),60))+"" +
                                "          "+Math.floorDiv(-duration.toMinutes(),60));
                        duree.setText(Math.floorDiv(-duration.toMinutes(),60)+"h et "+Math.floorMod(-duration.toMinutes(),60)+"min");
                    }
                    else
                    {
                        duree.setText(response1.body().getLastOffOn().get(0).getHeures()+"h et "+
                                response1.body().getLastOffOn().get(0).getMinutes()+"min");

                    }
                }}

            @Override
            public void onFailure(Call<HistoriquesDevice> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage()+"4");

            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_app_bar_details, menu);
        System.out.println("darr menu");
        return true;
    }
    private Toolbar.OnMenuItemClickListener  tbMenuLisner= new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();
            //noinspection SimplifiableIfStatement
            if (id == R.id.retour) {
                System.out.println("dkheel bch pressed");
                supportFinishAfterTransition();
                System.out.println(" pressed");
                return true;
            }
            return false;
        }
    };
}
