package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class HistoriqueDevice {

    @SerializedName("Historique_ID")
    @Expose
    private int historiqueID;


    @SerializedName("heures")
    @Expose
    private int heures;


    @SerializedName("minutes")
    @Expose
    private int minutes;

    @SerializedName("Historique_Appareil_ID")
    @Expose
    private int Historique_Appareil_ID;
    @SerializedName("Historique_Date")
    @Expose
    private String historiqueDate;

    @SerializedName("Historique_Date_Off")
    @Expose
    private String Historique_Date_Off;
    @SerializedName("Historique_Date_On")
    @Expose
    private String Historique_Date_On;



    @SerializedName("Historique_Description")
    @Expose
    private String  historiqueDescription;
    @SerializedName("Historique_Mode")
    @Expose
    private int historiqueMode;

    public int getHistoriqueID() {
        return historiqueID;
    }

    public void setHistoriqueID(int historiqueID) {
        this.historiqueID = historiqueID;
    }

    public String getHistoriqueDate() {
        return historiqueDate;
    }

    public void setHistoriqueDate(String historiqueDate) {
        this.historiqueDate = historiqueDate;
    }

    public String  getHistoriqueDescription() {
        return historiqueDescription;
    }

    public void setHistoriqueDescription(String  historiqueDescription) {

        this.historiqueDescription = historiqueDescription;
    }

    public int getHistoriqueMode() {
        return historiqueMode;
    }

    public void setHistoriqueMode(int historiqueMode) {
        this.historiqueMode = historiqueMode;
    }

    public int getHistorique_Appareil_ID() {
        return Historique_Appareil_ID;
    }

    public void setHistorique_Appareil_ID(int historique_Appareil_ID) {
        Historique_Appareil_ID = historique_Appareil_ID;
    }

    public int getHeures() {
        return heures;
    }

    public int getMinutes() {
        return minutes;
    }

    public String getHistorique_Date_Off() {
        return Historique_Date_Off;
    }

    public String getHistorique_Date_On() {
        return Historique_Date_On;
    }
}
