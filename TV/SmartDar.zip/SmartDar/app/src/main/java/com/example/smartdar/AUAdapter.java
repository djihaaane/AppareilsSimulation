package com.example.smartdar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.models.AU;

import java.util.ArrayList;

public class AUAdapter extends RecyclerView.Adapter<AUAdapter.MyViewHolder> {
    private Context context;
     ArrayList<AU> scList;
    private OnItemClickListener clickListener;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener  {
        public TextView chambre_title;
        public ImageView chambre_image;


        public MyViewHolder(View view) {
            super(view);
            chambre_title = view.findViewById(R.id.title_au);
            chambre_image = view.findViewById(R.id.image_au);

            view.setTag(view);
            view.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            if (clickListener != null)
            {clickListener.onClick(view, getAdapterPosition());
            }

        }
    }


    public AUAdapter(Context context, ArrayList<AU> scList) {
        this.context = context;
        this.scList = scList;

    }

    @Override
    public AUAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sos_card, parent, false);

        return new AUAdapter.MyViewHolder(itemView);
    }


    public void setClickListener(OnItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }
    @Override
    public void onBindViewHolder(AUAdapter.MyViewHolder holder, final int position) {


        holder.chambre_title.setText(scList.get(position).getName());
        holder.chambre_image.setImageDrawable(scList.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return scList.size();
    }
}
