package com.example.smartdar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.models.HistoriqueScenario;

import java.util.List;

public class HistoriqueScenarioAdapter extends RecyclerView.Adapter<HistoriqueScenarioAdapter.MyViewHolder> {

     private Context context;
        private List<HistoriqueScenario> histoList;

    public HistoriqueScenarioAdapter(Context details_scenario, List<HistoriqueScenario> listHist) {
        this.context = context;
        this.histoList = listHist;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
            public TextView histo_date;

            public MyViewHolder(View view) {
                super(view);
                histo_date = view.findViewById(R.id.histo_time);
            }
        }

        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.historique_card_scenario, parent, false);

            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(HistoriqueScenarioAdapter.MyViewHolder holder, final int position) {
            holder.histo_date.setText(histoList.get(position).getHistoriqueDate());
        }

        @Override
        public int getItemCount() {
            return histoList.size();
        }
    }