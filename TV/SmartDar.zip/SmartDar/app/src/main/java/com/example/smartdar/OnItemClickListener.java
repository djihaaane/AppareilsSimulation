package com.example.smartdar;

import android.view.View;

import com.google.android.material.card.MaterialCardView;

public interface OnItemClickListener {
    public void onClick(View view, int position);
}