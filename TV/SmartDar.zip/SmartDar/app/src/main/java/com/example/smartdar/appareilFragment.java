package com.example.smartdar;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.listChambre;
import com.google.android.material.card.MaterialCardView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link appareilFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class appareilFragment extends Fragment implements OnItemClickListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    private final String localhost="http://192.168.8.100/RetrofitSmartDar/Images/Chambre/";


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private final Handler handler;
    ImageButton simpleImageButton;
    private chambreAdapter adapter1;

    private RecyclerView recyclerViewa;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public appareilFragment() {
        // Required empty public constructor
        handler = new Handler();

    }
    public static appareilFragment newInstance(String param1, String param2) {
        appareilFragment fragment = new appareilFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        fetchData();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_appareils, container, false);
        recyclerViewa = view.findViewById(R.id.recycler_viewc);
        recyclerViewa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        fetchData();
        return view;

    }
    private void fetchData() {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);

        Call <listChambre> call = api.get_all_chambre();

        call.enqueue(new Callback<listChambre>() {
            @Override
            public void onResponse(Call<listChambre> call, Response<listChambre> response) {
                adapter1 = new chambreAdapter(getContext(),response.body().getChambres());
                recyclerViewa.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
                recyclerViewa.setAdapter(adapter1);
                adapter1.setClickListener(appareilFragment.this);
            }

            @Override
            public void onFailure(Call<listChambre> call, Throwable t) {

                Toast.makeText(getContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchData();
    }

    @Override
    public void onClick(View view, int position) {
        Intent intent= new Intent(getContext().getApplicationContext(), Details_chambre.class);
        Bundle b = new Bundle();
        b.putInt("chambre_id",adapter1.scList.get(position).getChambreID());
        b.putString("chambre_name",adapter1.scList.get(position).getChambreName());
        b.putString("chambre_image",localhost+adapter1.scList.get(position).getChambreImage());
        intent.putExtras(b);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().getApplicationContext().startActivity(intent);

    }
}