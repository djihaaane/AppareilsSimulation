package com.example.smartdar;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.listScenario;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ScenariosFragment extends Fragment  implements OnItemClickListener {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private final Handler handler;
    private ScenarioAdapter adapter1;

    private RecyclerView recyclerViews;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ScenariosFragment() {
        // Required empty public constructor
        handler = new Handler();

    }
    public static ScenariosFragment newInstance(String param1, String param2) {
        ScenariosFragment fragment = new ScenariosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_scenarios, container, false);
        recyclerViews = view.findViewById(R.id.recycler_views);
        recyclerViews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
         fetchData();
         return view;
    }


    private void fetchData() {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);

        Call<listScenario> call = api.get_all_scenario();

        call.enqueue(new Callback<listScenario>() {
            @Override
            public void onResponse(Call<listScenario> call, Response<listScenario> response) {
                adapter1 = new ScenarioAdapter(getContext(),response.body().getScenarios());
                recyclerViews.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
                recyclerViews.setAdapter(adapter1);
                adapter1.setClickListener(ScenariosFragment.this);


            }

            @Override
            public void onFailure(Call<listScenario> call, Throwable t) {

                Toast.makeText(getContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }
    @Override
    public void onResume() {
        fetchData();
        super.onResume();
    }

    @Override
    public void onClick(View view, int position) {

        Intent intent= new Intent(getContext().getApplicationContext(), Details_Scenario.class);
        Bundle b = new Bundle();
        b.putInt("scenario_id",adapter1.scList.get(position).getScenarioID());
        b.putString("scenario_name",adapter1.scList.get(position).getScenarioName());
        b.putString("scenario_nbrApp",adapter1.scList.get(position).getNbrApp());
        b.putString("class","Scenario");
        intent.putExtras(b);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().getApplicationContext().startActivity(intent);

    }
}
