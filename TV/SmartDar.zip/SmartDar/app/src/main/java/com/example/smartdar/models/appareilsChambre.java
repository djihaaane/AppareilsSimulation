package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class appareilsChambre {
    @SerializedName("appareilsChambre")
    @Expose
    private ArrayList<Device> appareilsChambre;

    @SerializedName("appareilsNotScenario")
    @Expose
    private ArrayList<Device> appareilNotsScenario;

    public appareilsChambre() {
    }

    public ArrayList<Device> getAppareilsChambre() {
        return appareilsChambre;
    }

    public void setAppareilsChambre(ArrayList<Device> appareilsChambre) {
        this.appareilsChambre = appareilsChambre;
    }


    public ArrayList<Device> getAppareilNotsScenario() {
        return appareilNotsScenario;
    }

    public void setAppareilNotsScenario(ArrayList<Device> appareilNotsScenario) {
        this.appareilNotsScenario = appareilNotsScenario;
    }
}
