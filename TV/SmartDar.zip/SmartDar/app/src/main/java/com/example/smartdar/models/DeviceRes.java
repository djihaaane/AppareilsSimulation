package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DeviceRes {
    @SerializedName("Appareil_ID")
    @Expose
    public int appareilID;
    @SerializedName("Appareil_Mode")
    @Expose
    public int appareilMode;

    public DeviceRes(int appareilID, int appareilMode) {
        this.appareilID = appareilID;
        this.appareilMode = appareilMode;
    }

    public int getAppareilID() {
        return appareilID;
    }

    public void setAppareilID(int appareilID) {
        this.appareilID = appareilID;
    }

    public int getAppareilMode() {
        return appareilMode;
    }

    public void setAppareilMode(int appareilMode) {
        this.appareilMode = appareilMode;
    }
}
