package com.example.smartdar;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.Device;
import com.example.smartdar.models.HistoriquesScenario;
import com.example.smartdar.models.Result;
import com.example.smartdar.models.appareilsScenario;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Details_Scenario extends AppCompatActivity implements OnButtonClickListener {
    private final Handler handler;
    RecyclerView recyclerView;
    RecyclerView recyclerView1;
    TextView scenario_name;
    TextView textActive;
    TextView nbr_app;
    static String nbrApp;
     Bundle bundle;
    public MaterialButton btnLancer;

    HistoriqueScenarioAdapter adapter;
    private Toolbar toolbar;
    private DeviceAdapterScenario adapter1;
    private OnButtonClickListener listner;
    private FloatingActionButton btnadd;
    String result;
    MaterialButton afficher;
    private int nbr=0;
    int message=0;
    int pos ;
    String type;
    String ip;
    private Thread1 Thread1;
    private boolean i=false;

    public Details_Scenario() {
        handler = new Handler();

    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details__scenario);
        recyclerView =(RecyclerView) findViewById(R.id.recycler_view);
        btnadd =(FloatingActionButton) findViewById(R.id.fab);
        afficher =(MaterialButton) findViewById(R.id.afficherHist);
        scenario_name =(TextView) findViewById(R.id.scenario_name_details);
        textActive =(TextView) findViewById(R.id.textActive);
        nbr_app =(TextView) findViewById(R.id.nbr_app_sce_details);
        recyclerView1 =(RecyclerView) findViewById(R.id.recycler_view1);
        toolbar= (Toolbar)findViewById(R.id.toolbardetail);
        LinearLayout layout= (LinearLayout) findViewById(R.id.layout_his);


        toolbar.setOnMenuItemClickListener(tbMenuLisner);
        btnLancer =findViewById(R.id.scenario_lancer);

        afficher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!i)
                {
                    layout.setVisibility(View.VISIBLE);
                    afficher.setText("Cacher historique");
                    i=true;
                }else
                {
                 layout.setVisibility(View.GONE);
                 i=false;
                }
            }
        });
        listner=this;
         bundle = getIntent().getExtras();
        result =String.valueOf(bundle.getInt("scenario_id"));
        String name=bundle.getString("scenario_name");
        scenario_name.setText(name);
        fetchData(result);
        nbrApp = bundle.getString("scenario_nbrApp");
         nbr_app.setText(nbrApp);
       btnLancer.setOnClickListener(new  View.OnClickListener(){
            @Override
            public void onClick(View v) {
               lancer(result);
                Toast.makeText(getApplicationContext(), "Routine lancer avec succès", Toast.LENGTH_SHORT).show();


            }});

        btnadd.setOnClickListener(new  View.OnClickListener(){@Override
        public void onClick(View v) {

           Intent intent= new Intent(v.getContext(), ActivityDajout.class);
           Bundle b = new Bundle();
           b.putString("scenario_id",result);
           intent.putExtras(b);
           startActivityForResult(intent, 2);
        }
        });

  }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println(requestCode);
        // check if the request code is same as what is passed  here it is 2
        if(requestCode==2)
        {
            if (data==null)
            {
                message=0;
            }else {
             message=getIntent().getIntExtra("nbr",0);
            }
            nbr_app.setText(String.valueOf(message+adapter1.deviceList.size()));
        }
    }
    private void fetchData(String id) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);


        Call<appareilsScenario> call1 = api.get_all_appareilsScenario(id);
        Call<HistoriquesScenario> call = api.get_all_historiques_scenario(id);
        Call<HistoriquesScenario> call2 = api.lastScenario(id);


        call1.enqueue(new Callback<appareilsScenario>() {
            @Override
            public void onResponse(Call<appareilsScenario> call, Response<appareilsScenario> response) {
                adapter1 = new DeviceAdapterScenario(getApplicationContext(),response.body().getAppareilsScenario(),listner,Integer.valueOf(id));
                recyclerView1.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));
                recyclerView1.setAdapter(adapter1);

            }

            @Override
            public void onFailure(Call<appareilsScenario> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();

            }
        });

        call.enqueue(new Callback<HistoriquesScenario>() {
            @Override
            public void onResponse(Call<HistoriquesScenario> call, Response<HistoriquesScenario> response) {
                adapter = new HistoriqueScenarioAdapter(getApplicationContext(),response.body().
                        getHistoriqueScenario());
                recyclerView.setLayoutManager(new LinearLayoutManager(
                        getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                recyclerView.setAdapter(adapter);


            }

            @Override
            public void onFailure(Call<HistoriquesScenario> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();

            }
        });

        call2.enqueue(new Callback<HistoriquesScenario>() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onResponse(Call<HistoriquesScenario> call, Response<HistoriquesScenario>
                    response) {
                if (response.body()!=null) {
                if (response.body().getLastScenario().isEmpty())
                    { textActive.setText("-");}
                    else {
                    SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date d = null;
                    try {
                        //convert string to date
                            d = inputFormat.parse(response.body()
                                    .getLastScenario().get(0).getHistoriqueDate());
                    } catch (ParseException e) {
                        System.out.println("Date Format Not Supported");
                        e.printStackTrace();
                    }
                    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Timestamp timestamp = Timestamp.valueOf(outputFormat.format(d));
                    System.out.println(timestamp);
                    Date date= new Date();
                    //getTime() returns current time in milliseconds
                    long time = date.getTime();
                    //Passed the milliseconds to constructor of Timestamp class
                    Timestamp ts = new Timestamp(time);
                    System.out.println("Current Time Stamp: "+ts);
                    Duration duration= Duration.between(ts.toInstant(),timestamp.toInstant());
                    System.out.println(duration.toMinutes());
                    System.out.println(( Math.floorMod(-duration.toMinutes(),60))+"          "+Math.floorDiv(-duration.toMinutes(),60));


                    textActive.setText(response.body()
                            .getLastScenario().get(0).getHistoriqueDate());

                    }}}

            @Override
            public void onFailure(Call<HistoriquesScenario> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_app_bar_details, menu);
        return true;
    }
    private Toolbar.OnMenuItemClickListener  tbMenuLisner= new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();
            //noinspection SimplifiableIfStatement
            if (id == R.id.retour) {
                supportFinishAfterTransition();
                return true;
            }
            return false;
        }
    };

    @Override
    public void showModifierDialog() {

        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.edit_dialog);
        dialog.setCancelable(true);
        com.kyleduo.switchbutton.SwitchButton etat =(com.kyleduo.switchbutton.SwitchButton) dialog.findViewById(R.id.etat_edit);
        if(adapter1.etatedit==1)
        {
           etat.setChecked(true);

        }
        else
        {  etat.setChecked(false);
        }
        EditText desc=(EditText)dialog.findViewById(R.id.desc_edit);
        desc.setText(adapter1.descedit);
        LinearLayout info=dialog.findViewById(R.id.info);
        System.out.println(adapter1.type);
        TextView infoText=dialog.findViewById(R.id.infoText);
        if (adapter1.type.equals("Smart TV") )
        {    info.setVisibility(View.VISIBLE);
            infoText.setText("Chaine :");
        }
       if (adapter1.type.equals("Climatiseur")||adapter1.type.equals("Radiateur"))
       {
           info.setVisibility(View.VISIBLE);
       }
        MaterialButton edit_button=(MaterialButton)dialog.findViewById(R.id.edit_button);
        MaterialButton cancel_button=(MaterialButton)dialog.findViewById(R.id.cancel_button);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        final int[] etatt = new int[1];
        edit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etat.isChecked()){
                    etatt[0] = 1;
                }
                else{
                    etatt[0] = 0;
                    }
                modifierAppareilScenario(adapter1.appareil_id,Integer.valueOf(result), String.valueOf(etatt[0]),desc.getText().toString());
               adapter1.deviceList.get(adapter1.pos).setAppareil_scenario_mode(etatt[0]);
               System.out.println(adapter1.pos);
                adapter1.deviceList.get(adapter1.pos).setAppareil_scenario_desc(desc.getText().toString());
               adapter1.notifyItemChanged(adapter1.pos);
                adapter1.notifyDataSetChanged();

                dialog.dismiss();
            }
        });

        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();

    }

    @Override
    public void showSupprimerDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.delete_dialog);
        dialog.setCancelable(true);

        MaterialButton delete_button=(MaterialButton)dialog.findViewById(R.id.delete_button);
        MaterialButton cancel_button=(MaterialButton)dialog.findViewById(R.id.cancel_button);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                supprimerAppareilScenario(adapter1.deviceList.get(adapter1.poss).getAppareilID(),Integer.valueOf(result));
                adapter1.deviceList.remove(adapter1.poss);
                adapter1.notifyItemRemoved(adapter1.poss);
                adapter1.notifyDataSetChanged();
                nbr_app.setText(String.valueOf(adapter1.deviceList.size()));
                dialog.dismiss();
            }
        });

        cancel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();

    }
    private void supprimerAppareilScenario(int Appareil_ID,int Scenario_ID) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        String id=String.valueOf(Appareil_ID).trim();
        String mod=String.valueOf(Scenario_ID).trim();
        Call<Result> call = api.supprimerAppareilScenario(id,mod);
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(Details_Scenario.this, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void modifierAppareilScenario(int Appareil_ID, int Scenario_ID, String Appareil_Scenario_Mode, String Appareil_Scenario_Desc) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        String id = String.valueOf(Appareil_ID).trim();
        String mod = String.valueOf(Scenario_ID).trim();
        Call<Result> call = api.modifierAppareilScenario(mod, id, Appareil_Scenario_Mode, Appareil_Scenario_Desc);
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(Details_Scenario.this, "" + t.getMessage().toString(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        fetchData(result);
    }
    private void lancer(String id) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);

        Call<appareilsScenario> call = api.get_all_appareilsScenario(id);
        Call<Result> call1=api.sendHistorique(id);

        call.enqueue(new Callback<appareilsScenario>() {
            @Override
            public void onResponse(Call<appareilsScenario> call, Response<appareilsScenario> response) {
                ArrayList<Device> li=response.body().getAppareilsScenario();
                for(int i=0;i<li.size();i++){

                    if (!li.get(i).getAppareilIP().equals("0"))
                    {
                        pos=li.get(i).getAppareil_scenario_mode();
                        type=li.get(i).getAppareilTypeName();
                        ip=li.get(i).getAppareilIP();
                        Thread1 =new Thread1();
                        Thread1.start();
                    }

                    String id=String.valueOf(li.get(i).getAppareilID()).trim();
                    String mod=String.valueOf(li.get(i).getAppareil_scenario_mode()).trim();
                    Call<Result> call1=api.sendAppareilMode(mod,id);
                    Call<Result> call2 =api.sendHistoriqueAppareil(id,mod,li.get(i).getAppareil_scenario_desc());
                    call1.enqueue(new Callback<Result>() {
                        @Override
                        public void onResponse(Call<Result> call, Response<Result> response) {
                            System.out.println(response.body().getMessage());

                        }

                        @Override
                        public void onFailure(Call<Result> call, Throwable t) {

                            Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            System.out.println(t.getMessage());

                        }
                    });
                    call2.enqueue(new Callback<Result>() {
                        @Override
                        public void onResponse(Call<Result> call, Response<Result> response) {
                            System.out.println(response.body().getMessage()+"         historiqueApppareil");

                        }

                        @Override
                        public void onFailure(Call<Result> call, Throwable t) {

                            Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            System.out.println(t.getMessage());

                        }
                    });
                }

            }

            @Override
            public void onFailure(Call<appareilsScenario> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
        call1.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }

    private PrintWriter output;
    private BufferedReader input;

    public class Thread1 extends Thread implements Runnable {
        public void run() {
            Socket socket;
            try {
                System.out.println(ip);
                socket = new Socket(ip, 8080);
                output = new PrintWriter(socket.getOutputStream());

                PrintWriter writer = new PrintWriter(output, true);
                System.out.println(pos);
                writer.println(pos);
                writer.println(type);
                System.out.println(type);
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}