package com.example.smartdar;

interface OnButtonClickListener {
    void showModifierDialog();
    void showSupprimerDialog();
}
