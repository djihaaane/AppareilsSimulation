package com.example.smartdar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.models.Device;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.List;

class DeviceAdapterScenario extends RecyclerView.Adapter<DeviceAdapterScenario.MyViewHolder> {
    private final String localhost="http://192.168.8.100/RetrofitSmartDar/Images/Appareil/";
     OnButtonClickListener listener;
    private  SwitchMaterial device_mode;
   private final int id;
    protected Context context;
    public List<Device> deviceList;
    int appareil_id;
    int etatedit;
    int pos;
    int poss;
    static int size;

    String descedit;
     String type;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private final com.kyleduo.switchbutton.SwitchButton device_mode;
        public TextView device_title;
        public ImageView device_image;
        public TextView device_room;
        public ImageButton btnEdit;
        public ImageButton btnDelete;

        public MyViewHolder(View view) {
            super(view);
            device_title = view.findViewById(R.id.device_title);
            device_image = view.findViewById(R.id.device_image);
            device_room = view.findViewById(R.id.device_room);
            device_mode = view.findViewById(R.id.device_mode);
            btnDelete=view.findViewById(R.id.deleteAppareil);
            btnEdit=view.findViewById(R.id.editAppareil);


        }
    }


    public DeviceAdapterScenario(Context context, List<Device> deviceList, OnButtonClickListener listener, int id) {
        this.context = context;
        this.deviceList = deviceList;
        this.listener = listener;

        this.id = id;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.device_scenario_card, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(DeviceAdapterScenario.MyViewHolder holder, final int position) {
        GlideApp.with(context)
                .load(localhost+deviceList.get(position).getAppareilTypeImage()).into(holder.device_image);
        holder.device_room.setText(deviceList.get(position).getAppareilChambre());
        holder.device_title.setText(deviceList.get(position).getAppareilName());
        if(deviceList.get(position).getAppareil_scenario_mode()==1)
        {
            holder.device_mode.setChecked(true);
            holder.device_mode.setClickable(false);}
        else
        {   holder.device_mode.setChecked(false);
            holder.device_mode.setClickable(false);}


             holder.btnEdit.setOnClickListener(new  View.OnClickListener(){@Override
             public void onClick(View v) {
               appareil_id=deviceList.get(position).getAppareilID();
                 etatedit=deviceList.get(position).getAppareil_scenario_mode();
                 descedit=deviceList.get(position).getAppareil_scenario_desc();
                 type=deviceList.get(position).getAppareilTypeName();
                 pos=position;

                 listener.showModifierDialog();



             }});
        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                poss=position;
                listener.showSupprimerDialog();

            }
        });
        size=deviceList.size();
    }
    @Override
    public int getItemCount() {
        return deviceList.size();
    }



    public void setDevice_mode(boolean b) {
        this.device_mode.setChecked(b);

    }
}