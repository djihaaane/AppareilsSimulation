package com.example.smartdar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.Result;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.iid.FirebaseInstanceId;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    TextInputLayout passwordTextInput;
    TextInputEditText passwordEditText;
    MaterialButton nextButton;
    TextInputEditText usernameEditText;
    String error="";
    private SharedPreferences sharedpreferences;
    private TextInputLayout usernameTextInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedpreferences = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener( this, instanceIdResult -> {
            String newToken = instanceIdResult.getToken();
            Log.e("newToken",newToken);
            System.out.println(newToken);

        });
        boolean login = sharedpreferences.getBoolean("error", true);
        if (!login)
        { super.onCreate(savedInstanceState);
            Intent intent= new Intent(getApplicationContext(), Login.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
        else {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);

            passwordTextInput = findViewById(R.id.password_text_input);
            usernameTextInput = findViewById(R.id.username_text_input);
            passwordEditText = findViewById(R.id.password_edit_text);
            usernameEditText = findViewById(R.id.username_edit_text);
            nextButton = findViewById(R.id.next_button);


            // Set an error if the password is less than 8 characters.
            nextButton.setOnClickListener(view -> {
               isPasswordValid(String.valueOf(passwordEditText.getText()),
                        String.valueOf(usernameEditText.getText()));
            });
        }}
    public void isPasswordValid(String mdp,String uti) {

        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);

        Call<Result> call = api.userPass(uti, mdp);

        call.enqueue(new Callback<Result>() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                assert response.body() != null;
                error =response.body().getError();
                if (error.equals("true")) {
                    usernameTextInput.setError(" ");
                    passwordTextInput.setError(getString(R.string.shr_error_password));


                }
                else {
                    passwordTextInput.setError(null);// Clear the error
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putBoolean("error",false);
                    editor.apply();
                    Intent intent= new Intent(getApplicationContext(), Login.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }


            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(getApplicationContext(), "" + t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }

});}

  }

