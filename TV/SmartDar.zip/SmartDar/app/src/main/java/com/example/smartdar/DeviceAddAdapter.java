package com.example.smartdar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.Device;
import com.example.smartdar.models.Result;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
    class DeviceAddAdapter extends RecyclerView.Adapter<com.example.smartdar.DeviceAddAdapter.MyViewHolder> {
        private final String localhost="http://192.168.8.100/RetrofitSmartDar/Images/Appareil/";
        private ArrayList<Device> arraylist;
        private Context context;
        protected List<Device> DeviceList;
        private OnItemClickListener clickListener;
        int pos;


        public void filter(String text) {
            text = text.toLowerCase(Locale.getDefault());
            DeviceList.clear();
            if (text.length() == 0) {
                DeviceList.addAll(arraylist);
            } else {
                for (Device wp : arraylist) {
                    if (wp.getAppareilName().toLowerCase(Locale.getDefault()).contains(text)) {
                        DeviceList.add(wp);
                    }
                }
            }
            notifyDataSetChanged();
        }

        public void setClickListener(com.example.smartdar.OnItemClickListener itemClickListener) {
            this.clickListener = itemClickListener;
        }

        public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            public TextView Device_title;
            public TextView Device_room;
            public ImageView Device_image;
            public MyViewHolder(View view) {
                super(view);
                Device_title = view.findViewById(R.id.device_title);
                Device_image = view.findViewById(R.id.device_image);
                Device_room =view.findViewById(R.id.device_room);
                view.setTag(view);
                view.setOnClickListener(this);

            }


            @Override
            public void onClick(View view) {
                if (clickListener != null)
                {clickListener.onClick(view, getAdapterPosition());
                pos=getAdapterPosition();
                }

            }
        }


        public DeviceAddAdapter(Context context, List<Device> DeviceList) {
            this.context = context;
            this.DeviceList = DeviceList;
            this.arraylist = new ArrayList<Device>();
            this.arraylist.addAll(DeviceList);



        }

        @Override
        public com.example.smartdar.DeviceAddAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.add_scenario_device_card, parent, false);

            return new com.example.smartdar.DeviceAddAdapter.MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(com.example.smartdar.DeviceAddAdapter.MyViewHolder holder, final int position) {
            GlideApp.with(context)
                    .load(localhost+DeviceList.get(position).getAppareilTypeImage()).into(holder.Device_image);
            holder.Device_room.setText(DeviceList.get(position).getAppareilChambre());
            holder.Device_title.setText(DeviceList.get(position).getAppareilName());

        }
        private void fetchData(int Appareil_ID,int Appareil_Mode) {
            GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
            String id=String.valueOf(Appareil_ID).trim();
            String mod=String.valueOf(Appareil_Mode).trim();
            Call<Result> call = api.sendAppareilMode(mod,id);

            call.enqueue(new Callback<Result>() {
                @Override
                public void onResponse(Call<Result> call, Response<Result> response) {
                    System.out.println(response.body().getMessage());

                }

                @Override
                public void onFailure(Call<Result> call, Throwable t) {

                    Toast.makeText(context, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                    System.out.println(t.getMessage());

                }
            });
        }

        @Override
        public int getItemCount() {
            return DeviceList.size();
        }

    }

