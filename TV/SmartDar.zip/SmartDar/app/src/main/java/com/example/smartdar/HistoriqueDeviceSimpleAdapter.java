package com.example.smartdar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.models.HistoriqueDevice;

import java.util.List;

public class HistoriqueDeviceSimpleAdapter extends RecyclerView.Adapter<HistoriqueDeviceSimpleAdapter.MyViewHolder> {

    private Context context;
    private List<HistoriqueDevice> histoList;

    public HistoriqueDeviceSimpleAdapter(Context details_scenario, List<HistoriqueDevice> listHist) {
        this.context = context;
        this.histoList = listHist;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView histo_date;
        public TextView hist_mode;
        public TextView hist_desc;


        public MyViewHolder(View view) {
            super(view);
            histo_date = view.findViewById(R.id.histo_time);
            hist_mode=view.findViewById(R.id.histo_etat);

        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.historique_card_appareil, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(HistoriqueDeviceSimpleAdapter.MyViewHolder holder, final int position) {
        holder.histo_date.setText(histoList.get(position).getHistoriqueDate());
        if(histoList.get(position).getHistoriqueMode()==1)
        {
            holder.hist_mode.setText("ON");

        }
        else {
            holder.hist_mode.setText("OFF");

        }
    }

    @Override
    public int getItemCount() {
        return histoList.size();
    }
}

