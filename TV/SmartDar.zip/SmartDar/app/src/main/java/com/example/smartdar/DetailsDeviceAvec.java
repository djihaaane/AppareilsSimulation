package com.example.smartdar;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.HistoriquesDevice;
import com.example.smartdar.models.Result;
import com.google.android.material.button.MaterialButton;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailsDeviceAvec extends AppCompatActivity {
    private final Handler handler;
    RecyclerView recyclerView;
    HistoriqueDeviceAdapter adapter;
    private TextView appareil_name;
    private com.kyleduo.switchbutton.SwitchButton appareil_mode;
    private TextView appareil_chambre;
    private TextView appareil_type;
    private TextView duree;
    private Toolbar toolbar;
    private TextView appareil_desc;
    private MaterialButton btninc;
    private MaterialButton btndecr;
    private MaterialButton changerTemp;
    private TextView active;
    private TextView desactive;
     static Timestamp timestamp,timestamp1,ts;
    int mod;
    String dn = "";
    String df = "";
    Date d = null;
    Date d1 = null;
    private boolean i=false;

    public DetailsDeviceAvec() {
        handler = new Handler();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_device_avec);
        recyclerView =(RecyclerView) findViewById(R.id.recycler_view1);
        appareil_name =(TextView) findViewById(R.id.appareil_name_details);
        duree =(TextView) findViewById(R.id.duree);
        appareil_chambre =(TextView) findViewById(R.id.chambre_name_app_details);
        appareil_type =(TextView) findViewById(R.id.type_app_details);
        appareil_desc =(TextView) findViewById(R.id.appareil_desc_details);
        appareil_mode=(com.kyleduo.switchbutton.SwitchButton)findViewById(R.id.device_mode_details);
        btninc =(MaterialButton )findViewById(R.id.inc);
        btndecr =(MaterialButton )findViewById(R.id.dinc);
        changerTemp =(MaterialButton )findViewById(R.id.changerTemp);
        active =(TextView) findViewById(R.id.textView5);
        MaterialButton afficher=findViewById(R.id.afficherHist);
        LinearLayout layout=findViewById(R.id.layout_his);


        desactive =(TextView) findViewById(R.id.textView4);
        toolbar= (Toolbar)findViewById(R.id.toolbardetail);
        toolbar.setOnMenuItemClickListener(tbMenuLisner);
        Bundle bundle = getIntent().getExtras();
        String result =String.valueOf(bundle.getInt("appareil_id"));
         mod=bundle.getInt("appareil_mode");
        int pos=bundle.getInt("pos");
        if(mod==1)
        {
            appareil_mode.setChecked(true);
            System.out.println(mod);}
        else
        {   appareil_mode.setChecked(false);
            System.out.println(mod);
        }

        appareil_mode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    fetchData(Integer.parseInt(result),1,appareil_desc.getText().toString());
                } else {
                    fetchData(Integer.parseInt(result),0,appareil_desc.getText().toString());

                }
            }
        });

        String name=bundle.getString("appareil_name");
        String desc=bundle.getString("appareil_info");
        String Appareil_Chambre=bundle.getString("Appareil_Chambre");
        String type=bundle.getString("appareil_type");
        int id=bundle.getInt("appareil_id");
        appareil_name.setText(name);
        appareil_chambre.setText(Appareil_Chambre);
        appareil_type.setText(type);
        appareil_desc.setText(desc);

        changerTemp.setVisibility(View.GONE);
        btninc.setVisibility(View.GONE);
        btndecr.setVisibility(View.GONE);
        if (type.equals("Climatiseur") ||
                type.equals("Radiateur"))
        {
            changerTemp.setVisibility(View.VISIBLE);
            btninc.setVisibility(View.VISIBLE);
            btndecr.setVisibility(View.VISIBLE);
        }
        btninc.setOnClickListener(new  View.OnClickListener(){@Override
        public void onClick(View v) {
            String s = appareil_desc.getText().toString();
            int i=Integer.valueOf(s)+1;
           System.out.println(i);
           appareil_desc.setText(String.valueOf(i));
                                   }
        });
        btndecr.setOnClickListener(new  View.OnClickListener(){@Override
        public void onClick(View v) {
            String s = appareil_desc.getText().toString();
            Integer i=Integer.valueOf(s)-1;

            appareil_desc.setText(String.valueOf(i));
        }
        });
        changerTemp.setOnClickListener(new  View.OnClickListener(){@Override
        public void onClick(View v) {
            fetchData2(id,appareil_desc.getText().toString());
        }
        });

        afficher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!i)
                {
                    layout.setVisibility(View.VISIBLE);
                    afficher.setText("Cacher historique");
                    i=true;
                }else
                {
                    layout.setVisibility(View.GONE);
                    i=false;
                }
            }
        });



        fetchData(result);
    }






    @SuppressLint("NewApi")
    private void fetchData(String appareil_id) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);


        Call<HistoriquesDevice> call = api.get_all_historiques_Appareil(appareil_id);
        Call<HistoriquesDevice> call1 = api.get_lastOffOn(appareil_id);



        call.enqueue(new Callback<HistoriquesDevice>() {
            @Override
            public void onResponse(Call<HistoriquesDevice> call, Response<HistoriquesDevice> response) {
                adapter = new HistoriqueDeviceAdapter(getApplicationContext(),response.body().getHistoriquesDevices());
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
                recyclerView.setAdapter(adapter);


            }

            @Override
            public void onFailure(Call<HistoriquesDevice> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage()+"2");

            }
        });

        call1.enqueue(new Callback<HistoriquesDevice>() {
            @Override
            public void onResponse(Call<HistoriquesDevice> call, Response<HistoriquesDevice> response1) {
                if (response1.body().getLastOffOn().isEmpty())
                {
                    desactive.setText("-");
                    active.setText("-");

                }
                else {

                    desactive.setText(response1.body().getLastOffOn().get(0).getHistorique_Date_Off());

                                active.setText(response1.body().getLastOffOn().get(0).getHistorique_Date_On());

                                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                Date d = null;
                                Date d1 = null;

                                try {
                                    //convert string to date
                                    d = inputFormat.parse(response1.body()
                                            .getLastOffOn().get(0).getHistorique_Date_On());
                                } catch (ParseException e) {
                                    System.out.println("Date Format Not Supported");
                                    e.printStackTrace();
                                }
                                SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                timestamp1 = Timestamp.valueOf(outputFormat.format(d));
                                Date date = new Date();
                                //getTime() returns current time in milliseconds
                                long time = date.getTime();
                                //Passed the milliseconds to constructor of Timestamp class
                                Timestamp ts = new Timestamp(time);
                                if (mod==1)
                                {
                                    Duration duration= Duration.between(ts.toInstant(),timestamp1.toInstant());
                                    System.out.println(duration.toMinutes());
                                    System.out.println(( Math.floorMod(-duration.toMinutes(),60))+"" +
                                            "          "+Math.floorDiv(-duration.toMinutes(),60));
                                    duree.setText(Math.floorDiv(-duration.toMinutes(),60)+"h et "+Math.floorMod(-duration.toMinutes(),60)+"min");
                                }
                                else
                                {
                                    duree.setText(response1.body().getLastOffOn().get(0).getHeures()+"h et "+
                                            response1.body().getLastOffOn().get(0).getMinutes()+"min");

                                }
                            }}

                        @Override
                        public void onFailure(Call<HistoriquesDevice> call, Throwable t) {

                            Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            System.out.println(t.getMessage()+"4");

                        }
                    });

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_app_bar_details, menu);
        System.out.println("darr menu");
        return true;
    }
    private void fetchData2(int Appareil_ID,String Appareil_Info) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        String id=String.valueOf(Appareil_ID).trim();
        String mod=String.valueOf(Appareil_Info).trim();
        Call<Result> call = api.sendAppareilDesc(mod,id);

        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(getApplication(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage()+"1");

            }
        });
    }
    private Toolbar.OnMenuItemClickListener  tbMenuLisner= new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();
            //noinspection SimplifiableIfStatement
            if (id == R.id.retour) {
                System.out.println("dkheel bch pressed");
                supportFinishAfterTransition();
                System.out.println(" pressed");
                return true;
            }
            return false;
        }
    };
    private void fetchData(int Appareil_ID,int Appareil_Mode,String Appareil_Desc) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        String id=String.valueOf(Appareil_ID).trim();
        String mod=String.valueOf(Appareil_Mode).trim();
        Call<Result> call = api.sendAppareilMode(mod,id);
        Call<Result> call1 = api.sendHistoriqueAppareil(id,mod,Appareil_Desc.trim());

        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
        call1.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage()+"0");

            }
        });
    }

}
