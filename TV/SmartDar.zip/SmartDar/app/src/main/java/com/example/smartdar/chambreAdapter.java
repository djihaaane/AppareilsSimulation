package com.example.smartdar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.models.Chambre;

import java.util.List;

class chambreAdapter extends RecyclerView.Adapter<chambreAdapter.MyViewHolder> {

    private final String localhost="http://192.168.8.100/RetrofitSmartDar/Images/Chambre/";

    private Context context;
    protected List<Chambre> scList;
    private OnItemClickListener clickListener;


    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView chambre_title;
        public ImageView chambre_image;
        public TextView chambre_nbrdevices;
        public ImageButton btnDetails;


        public MyViewHolder(View view)  {
            super(view);
            chambre_title = view.findViewById(R.id.chambre_name);
            chambre_image = view.findViewById(R.id.chambre_image);
            chambre_nbrdevices = view.findViewById(R.id.chambre_nbrdevices);
            btnDetails =view.findViewById(R.id.detailChambre);
            view.setTag(view);
            view.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            if (clickListener != null)
            {clickListener.onClick(view, getAdapterPosition());

            }

        }
    }


    public chambreAdapter(Context context, List<Chambre> scList) {
        this.context = context;
        this.scList = scList;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.chambre_card, parent, false);

        return new MyViewHolder(itemView);
    }
    public void setClickListener(OnItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    @Override
    public void onBindViewHolder(chambreAdapter.MyViewHolder holder, final int position) {
        GlideApp.with(context)
                .load(localhost+scList.get(position).getChambreImage()).into(holder.chambre_image);

        holder.chambre_title.setText(scList.get(position).getChambreName());
        holder.chambre_nbrdevices.setText(scList.get(position).getNbrApp());

        holder.btnDetails.setOnClickListener(new  View.OnClickListener(){@Override
        public void onClick(View v) {
            Intent intent= new Intent(context.getApplicationContext(), Details_chambre.class);
            Bundle b = new Bundle();
            b.putInt("chambre_id",scList.get(position).getChambreID());
            b.putString("chambre_name",scList.get(position).getChambreName());
            b.putString("chambre_image",localhost+scList.get(position).getChambreImage());
            intent.putExtras(b);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.getApplicationContext().startActivity(intent);

        }
        });

    }

    @Override
    public int getItemCount() {
        return scList.size();
    }
}