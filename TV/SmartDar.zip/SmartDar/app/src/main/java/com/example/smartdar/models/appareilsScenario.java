package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class appareilsScenario {
    @SerializedName("appareilsScenario")
    @Expose
    private ArrayList<Device> appareilsScenario;

    public ArrayList<Device> getAppareilsScenario() {
        return appareilsScenario;
    }

    public void setAppareilsScenario(ArrayList<Device> appareilsScenario) {
        this.appareilsScenario = appareilsScenario;
    }
}
