package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class listScenario {
    @SerializedName("scenarios")
    @Expose
    private ArrayList<Scenario> scenarios;


    @SerializedName("scenariosFav")
    @Expose
    private ArrayList<Scenario> scenariosFav;


    public listScenario() {
    }

    public ArrayList<Scenario> getScenarios() {
        return scenarios;
    }

    public void setScenarios(ArrayList<Scenario> scenarios) {
        this.scenarios = scenarios;
    }

    public ArrayList<Scenario> getScenariosFav() {
        return scenariosFav;
    }

    public void setScenariosFav(ArrayList<Scenario> scenariosFav) {
        this.scenariosFav = scenariosFav;
    }
}
