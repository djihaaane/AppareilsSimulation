package com.example.smartdar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.BounceInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.Device;
import com.example.smartdar.models.Result;
import com.example.smartdar.models.Scenario;
import com.example.smartdar.models.appareilsScenario;
import com.google.android.material.button.MaterialButton;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

class ScenarioAdapter extends RecyclerView.Adapter<ScenarioAdapter.MyViewHolder> {
    private final String localhost="http://192.168.8.100/RetrofitSmartDar/Images/Scenario/";

    public interface OnItemClickListener {
        void onItemClick(Scenario item);
    }


    private Context context;
    protected List<Scenario> scList;
    private com.example.smartdar.OnItemClickListener clickListener;
    ArrayList<Thread1> lii=new ArrayList<>();
    int pos ;
    String type;
    String ip;
    private PrintWriter output;
    private BufferedReader input;
    public void setClickListener(com.example.smartdar.OnItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }
    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView scenario_title;
        public ImageView scenario_image;
        public TextView scenario_nbrdevices;
        public ImageButton btnDetails;
        public MaterialButton btnLancer;
        public ToggleButton favorite;



        public MyViewHolder(View view) {
            super(view);
            scenario_title = view.findViewById(R.id.scenario_name);
            scenario_image = view.findViewById(R.id.scenario_image);
            scenario_nbrdevices = view.findViewById(R.id.scenario_nbrdevices);
            btnDetails =view.findViewById(R.id.detailScenario);
            btnLancer =view.findViewById(R.id.scenario_lancer);
            favorite = view.findViewById(R.id.button_favorite);
            view.setTag(view);
            view.setOnClickListener(this);

        }


        @Override
        public void onClick(View view) {
            if (clickListener != null)
            {clickListener.onClick(view, getAdapterPosition());

            }

        }
    }


    public ScenarioAdapter(Context context, List<Scenario> scList) {
        this.context = context;
        this.scList = scList;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.scenario_card, parent, false);

        return new MyViewHolder(itemView);
    }


    @Override
    public void onBindViewHolder(final ScenarioAdapter.MyViewHolder holder, final int position) {
        GlideApp.with(context)
                .load(localhost+scList.get(position).getScenarioImage()).into(holder.scenario_image);
        holder.scenario_title.setText(scList.get(position).getScenarioName());
        holder.scenario_nbrdevices.setText(scList.get(position).getNbrApp());
        holder.btnDetails.setOnClickListener(new  View.OnClickListener(){@Override
        public void onClick(View v) {

            Intent intent= new Intent(context.getApplicationContext(), Details_Scenario.class);
            Bundle b = new Bundle();
            b.putInt("scenario_id",scList.get(position).getScenarioID());
            b.putString("scenario_name",holder.scenario_title.getText().toString());
            b.putString("scenario_nbrApp",scList.get(position).getNbrApp());
            b.putString("class","Scenario");
            intent.putExtras(b);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.getApplicationContext().startActivity(intent);
        }
    });
        if (scList.get(position).isfavoris()==1)
        {
            holder.favorite.setChecked(true);
        }else
        {
            holder.favorite.setChecked(false);
        }
        ScaleAnimation scaleAnimation = new ScaleAnimation(0.7f, 1.0f, 0.7f, 1.0f, Animation.RELATIVE_TO_SELF, 0.7f, Animation.RELATIVE_TO_SELF, 0.7f);
        scaleAnimation.setDuration(500);
        BounceInterpolator bounceInterpolator = new BounceInterpolator();
        scaleAnimation.setInterpolator(bounceInterpolator);

        holder.favorite.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                //animation
                if (isChecked==true)
                {
                    sendFav(scList.get(position).getScenarioID(),1);
                }else
                {
                    sendFav(scList.get(position).getScenarioID(),0);
                }
                compoundButton.startAnimation(scaleAnimation);
            }});

        holder.btnLancer.setOnClickListener(new  View.OnClickListener(){
            @Override
        public void onClick(View v) {
            fetchData(String.valueOf(scList.get(position).getScenarioID()));
                Toast.makeText(context, "Routine lancer avec succès", Toast.LENGTH_SHORT).show();
                lii.clear();


            }});

    }
    @Override
    public int getItemCount() {
        return scList.size();
    }

    private void fetchData(String id) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        Call<appareilsScenario> call = api.get_all_appareilsScenario(id);
        Call<Result> call1=api.sendHistorique(id);

        call.enqueue(new Callback<appareilsScenario>() {
            @Override
            public void onResponse(Call<appareilsScenario> call, Response<appareilsScenario> response) {
                ArrayList<Device> li=response.body().getAppareilsScenario();
                for(int i=0;i<li.size();i++) {
                    lii.add(new Thread1());
                    System.out.println(i);
                    pos = li.get(i).getAppareil_scenario_mode();
                    type = li.get(i).getAppareilTypeName();
                    System.out.println(type);
                    ip = li.get(i).getAppareilIP();
                    System.out.println(ip);
                    if (!ip.equals("0")) {
                        lii.get(i).start();
                    }
                    String id = String.valueOf(li.get(i).getAppareilID()).trim();
                    String mod = String.valueOf(li.get(i).getAppareil_scenario_mode()).trim();
                    Call<Result> call1 = api.sendAppareilMode(mod, id);
                    Call<Result> call2 = api.sendHistoriqueAppareil(id, mod, li.get(i).getAppareil_scenario_desc());
                    call1.enqueue(new Callback<Result>() {
                        @Override
                        public void onResponse(Call<Result> call, Response<Result> response) {
                            System.out.println(response.body().getMessage());

                        }

                        @Override
                        public void onFailure(Call<Result> call, Throwable t) {

                            Toast.makeText(context, "" + t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            System.out.println(t.getMessage());

                        }
                    });
                    call2.enqueue(new Callback<Result>() {
                        @Override
                        public void onResponse(Call<Result> call, Response<Result> response) {
                            System.out.println(response.body().getMessage() + "         historiqueApppareil");

                        }

                        @Override
                        public void onFailure(Call<Result> call, Throwable t) {

                            Toast.makeText(context, "" + t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            System.out.println(t.getMessage());

                        }
                    });

                }

            }


            @Override
            public void onFailure(Call<appareilsScenario> call, Throwable t) {

                Toast.makeText(context, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
        call1.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(context, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }
    private void sendFav(int id,int fav) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);

        Call <Result> call = api.ScenarioFav(id,fav);

        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                System.out.println(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

                Toast.makeText(context, ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }



    public class Thread1 extends Thread implements Runnable {
        public void run() {
             lancerUnThread(ip,pos,type);
        }
    }

    public void lancerUnThread(String ip,int pos,String  type)
    {
        Socket socket;
        try {
            socket = new Socket(ip, 8080);
            output = new PrintWriter(socket.getOutputStream());

            PrintWriter writer = new PrintWriter(output, true);
            writer.println(pos);
            writer.println(type);
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            socket.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

