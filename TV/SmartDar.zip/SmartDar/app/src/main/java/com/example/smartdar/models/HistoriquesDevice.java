package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class HistoriquesDevice {
    @SerializedName("historiqueAppareil")
    @Expose
    private ArrayList<HistoriqueDevice> historiquesDevices;

    @SerializedName("lastOffOn")
    @Expose
    private ArrayList<HistoriqueDevice> lastOffOn;

    public ArrayList<HistoriqueDevice> getHistoriquesDevices() {
        return historiquesDevices;
    }

    public ArrayList<HistoriqueDevice> getLastOffOn() {
        return lastOffOn;
    }
}
