package com.example.smartdar;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.models.AU;

import java.util.ArrayList;

public class SosActivity extends AppCompatActivity implements OnItemClickListener {
    RecyclerView view;
    AUAdapter adapter;
    ArrayList<AU> list;
    private Toolbar toolbar;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sos);
        view = (RecyclerView) findViewById(R.id.recycler_viewau);
        toolbar= (Toolbar)findViewById(R.id.sos_toolbar);
        toolbar.setOnMenuItemClickListener(tbMenuLisner);
        list = new ArrayList<>();
        list.add(new AU(getDrawable(R.drawable.police), "Police", "1548"));
        list.add(new AU(getDrawable(R.drawable.gendarmerie), "Gendarmerie", "1055"));
        list.add(new AU(getDrawable(R.drawable.pc2), "Protection civile", "1021"));
        list.add(new AU(getDrawable(R.drawable.am), "SAMU", "3016"));
        adapter = new AUAdapter(this, list);
        GridLayoutManager mGridLayoutManager = new GridLayoutManager(getApplicationContext(), 2);
        view.setLayoutManager(mGridLayoutManager);
        view.setAdapter(adapter);
        adapter.setClickListener(SosActivity.this);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @Override
    public void onClick(View view, int position) {
        Intent callIntent = new Intent(Intent.ACTION_DIAL);
        callIntent.setData(Uri.parse("tel:"+Uri.encode( adapter.scList.get(position).getNum().trim())));
        callIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(callIntent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_app_bar_details, menu);
        return true;
    }
    private Toolbar.OnMenuItemClickListener  tbMenuLisner= new Toolbar.OnMenuItemClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();
            //noinspection SimplifiableIfStatement
            if (id == R.id.retour) {
                finishAfterTransition();
                return true;
            }
            return false;
        }
    };
}

