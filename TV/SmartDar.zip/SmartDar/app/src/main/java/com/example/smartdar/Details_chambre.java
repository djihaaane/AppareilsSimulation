package com.example.smartdar;

import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smartdar.api.GetDataService;
import com.example.smartdar.api.RetrofitClientInstance;
import com.example.smartdar.models.appareilsChambre;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Details_chambre extends AppCompatActivity {

    private final Handler handler;
    RecyclerView recyclerView1;
    DeviceAdapterchambre adapter;
    private Toolbar toolbar;
    private TextView chambre_name;
    private ImageView imageDetails;
    String result;

    public Details_chambre() {

        handler = new Handler();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_chambre);
        chambre_name =(TextView) findViewById(R.id.chambre_name_details);
        imageDetails =(ImageView) findViewById(R.id.chambre_details_image);
        recyclerView1 =(RecyclerView) findViewById(R.id.recycler_view1);
        toolbar= (Toolbar)findViewById(R.id.toolbardetailc);
        toolbar.setOnMenuItemClickListener(tbMenuLisner);
        Bundle bundle = getIntent().getExtras();
       result =String.valueOf(bundle.getInt("chambre_id"));
        String name= bundle.getString("chambre_name");
        String image=bundle.getString("chambre_image");
        chambre_name.setText(name);
        GlideApp.with(this)
                .load(image).into(imageDetails);
       fetchData(result);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.top_app_bar_details, menu);
        return true;
    }
    private Toolbar.OnMenuItemClickListener  tbMenuLisner= new Toolbar.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
            int id = menuItem.getItemId();
            //noinspection SimplifiableIfStatement
            if (id == R.id.retour) {
                System.out.println("dkheel bch pressed");
                supportFinishAfterTransition();
                System.out.println(" pressed");
                return true;
            }
            return false;
        }
    };

    private void fetchData(String chambre_id) {
        GetDataService api = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);


        Call<appareilsChambre> call = api.get_all_appareilsChambre(chambre_id);

        call.enqueue(new Callback<appareilsChambre>() {
            @Override
            public void onResponse(Call<appareilsChambre> call, Response<appareilsChambre> response) {
                System.out.println(response.body().getAppareilsChambre());
                adapter = new DeviceAdapterchambre(getApplicationContext(),response.body().getAppareilsChambre());
                GridLayoutManager mGridLayoutManager = new GridLayoutManager(Details_chambre.this, 2);
                recyclerView1.setLayoutManager(mGridLayoutManager);
                recyclerView1.setAdapter(adapter);


            }

            @Override
            public void onFailure(Call<appareilsChambre> call, Throwable t) {

                Toast.makeText(getApplicationContext(), ""+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
                System.out.println(t.getMessage());

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        fetchData(result);
    }

}
