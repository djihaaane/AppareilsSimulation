package com.example.smartdar.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Device {
    @SerializedName("Appareil_ID")
    @Expose
    private int appareilID;
    @SerializedName("Appareil_IP")
    @Expose
    private String appareilIP;
    @SerializedName("Appareil_Mac")
    @Expose
    private String appareilMac;
    @SerializedName("Appareil_Name")
    @Expose
    private String appareilName;
    @SerializedName("Appareil_Type_Image")
    @Expose
    private String appareilTypeImage;
    @SerializedName("Appareil_Info")
    @Expose
    private String Appareil_Info;
    @SerializedName("Appareil_Type_Name")
    @Expose
    private String appareilTypeName;
    @SerializedName("Appareil_Mode")
    @Expose
    private int appareilMode;
    @SerializedName("Appareil_chambre")
    @Expose
    private String appareilChambre;
    @SerializedName("appareil_scenario_mode")
    @Expose
    private int appareil_scenario_mode;
    @SerializedName("appareil_scenario_desc")
    @Expose
    private String appareil_scenario_desc;

    public Device(int id, int mode) {
        this.appareilID=id;
        this.appareilMode=mode;
    }

    public Device(int appareilID, int appareil_scenario_mode, String appareil_scenario_desc) {
        this.appareilID = appareilID;
        this.appareil_scenario_mode = appareil_scenario_mode;
        this.appareil_scenario_desc = appareil_scenario_desc;
    }

    public int getAppareilID() {
        return appareilID;
    }

    public void setAppareilID(int appareilID) {
        this.appareilID = appareilID;
    }

    public String getAppareilIP() {
        return appareilIP;
    }

    public void setAppareilIP(String appareilIP) {
        this.appareilIP = appareilIP;
    }

    public String getAppareilMac() {
        return appareilMac;
    }

    public void setAppareilMac(String appareilMac) {
        this.appareilMac = appareilMac;
    }

    public String getAppareilName() {
        return appareilName;
    }

    public void setAppareilName(String appareilName) {
        this.appareilName = appareilName;
    }

    public String getAppareilTypeImage() {
        return appareilTypeImage;
    }

    public void setAppareilTypeImage(String appareilTypeImage) {
        this.appareilTypeImage = appareilTypeImage;
    }

    public int getAppareilMode() {
        return appareilMode;
    }

    public void setAppareilMode(int appareilMode) {
        this.appareilMode = appareilMode;
    }

    public String getAppareilChambre() {
        return appareilChambre;
    }

    public void setAppareilChambre(String appareilChambre) {
        this.appareilChambre = appareilChambre;
    }

    public int getAppareil_scenario_mode() {
        return appareil_scenario_mode;
    }

    public void setAppareil_scenario_mode(int appareil_scenario_mode) {
        this.appareil_scenario_mode = appareil_scenario_mode;
    }

    public String getAppareilTypeName() {
        return appareilTypeName;
    }

    public void setAppareilTypeName(String appareilTypeName) {
        this.appareilTypeName = appareilTypeName;
    }

    public String getAppareil_Info() {
        return Appareil_Info;
    }

    public void setAppareil_Info(String appareil_Info) {
        Appareil_Info = appareil_Info;
    }

    public String getAppareil_scenario_desc() {
        return appareil_scenario_desc;
    }

    public void setAppareil_scenario_desc(String appareil_scenario_desc) {
        this.appareil_scenario_desc = appareil_scenario_desc;
    }
}
