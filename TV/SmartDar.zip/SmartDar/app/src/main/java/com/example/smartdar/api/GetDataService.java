package com.example.smartdar.api;

import com.example.smartdar.models.HistoriquesDevice;
import com.example.smartdar.models.HistoriquesScenario;
import com.example.smartdar.models.Result;
import com.example.smartdar.models.appareilsChambre;
import com.example.smartdar.models.appareilsON;
import com.example.smartdar.models.appareilsScenario;
import com.example.smartdar.models.listChambre;
import com.example.smartdar.models.listScenario;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface GetDataService {
    @GET("RetrofitSmartDar/public/chambres")
    Call <listChambre> get_all_chambre();

    @GET("RetrofitSmartDar/public/appareilsON")
    Call <appareilsON> get_all_appareilsON();


    @GET("RetrofitSmartDar/public/scenariosFav")
    Call <listScenario> scenariosFav();


    @GET("RetrofitSmartDar/public/scenarios")
    Call <listScenario> get_all_scenario();

    @GET("RetrofitSmartDar/public/appareilsChambre/{Chambre_ID}")
    Call<appareilsChambre> get_all_appareilsChambre(@Path("Chambre_ID") String chambre_id);

    @GET("RetrofitSmartDar/public/appareilsScenario/{Scenario_ID}")
    Call<appareilsScenario> get_all_appareilsScenario(@Path("Scenario_ID") String scenario_id);


    @GET("RetrofitSmartDar/public/appareilsNotScenario/{Scenario_ID}")
    Call<appareilsChambre> get_all_appareilsNotScenario(@Path("Scenario_ID") String scenario_id);


    @GET("RetrofitSmartDar/public/historiqueScenario/{Scenario_ID}")
    Call<HistoriquesScenario> get_all_historiques_scenario(@Path("Scenario_ID") String scenario_id);



    @GET("RetrofitSmartDar/public/historiqueAppareil/{Appareil_ID}")
    Call<HistoriquesDevice> get_all_historiques_Appareil(@Path("Appareil_ID") String appareil_id);


    @POST("RetrofitSmartDar/public/ScenarioFav")
    Call<Result> ScenarioFav(
            @Query("Scenario_ID") int  Scenario_ID,
            @Query("favoris") int favoris);


    @POST("RetrofitSmartDar/public/sendAppareilEtat")
    Call<Result> sendAppareilMode(
            @Query("Appareil_Mode") String  Appareil_Mode,
            @Query("Appareil_ID") String Appareil_ID);


    @POST("RetrofitSmartDar/public/supprimerAppareilScenario")
    Call<Result> supprimerAppareilScenario(
            @Query("Appareil_ID") String  Appareil_ID,
            @Query("Scenario_ID") String Scenario_ID);

    @POST("RetrofitSmartDar/public/userPass")
    Call<Result> userPass(
            @Query("Username") String  Username,
            @Query("Password") String Password);


    @POST("RetrofitSmartDar/public/sendAppareilDesc")
    Call<Result> sendAppareilDesc(
            @Query("Appareil_Info") String  Appareil_Info,
            @Query("Appareil_ID") String Appareil_ID);


    @POST("RetrofitSmartDar/public/sendHistorique")
    Call<Result> sendHistorique(
            @Query("Historique_Scenario_ID") String  Historique_Scenario_ID);


    @POST("RetrofitSmartDar/public/ajouterAppareilScenario")
    Call<Result> ajouterAppareilsScenario(
            @Query("Scenario_ID") String  Scenario_ID, @Query("Appareil_ID") String  Appareil_ID,@Query("Appareil_Scenario_Mode") String  Appareil_Scenario_Mode, @Query("Appareil_Scenario_Desc") String  Appareil_Scenario_Desc);

    @POST("RetrofitSmartDar/public/modifierAppareilScenario")
    Call<Result> modifierAppareilScenario(
            @Query("Scenario_ID") String  Scenario_ID, @Query("Appareil_ID") String  Appareil_ID,@Query("Appareil_Scenario_Mode") String  Appareil_Scenario_Mode, @Query("Appareil_Scenario_Desc") String  Appareil_Scenario_Desc);

    @POST("RetrofitSmartDar/public/sendHistoriqueAppareil")
    Call<Result> sendHistoriqueAppareil(
            @Query("Historique_Appareil_ID") String  Historique_Scenario_ID, @Query("Historique_Mode") String  Appareil_Mode,@Query("Historique_Desc") String  Historique_Desc);





    @GET("RetrofitSmartDar/public/lastScenario/{Scenario_ID}")
    Call<HistoriquesScenario> lastScenario(@Path("Scenario_ID") String scenario_id);

    @GET("RetrofitSmartDar/public/lastOffOn/{Appareil_ID}")
    Call<HistoriquesDevice> get_lastOffOn(@Path("Appareil_ID") String appareil_id);


}
